# Linux 应急响应排查

> 本文件覆盖 Linux 系统应急响应排查全流程：进程、网络、定时任务、日志、用户、Rootkit 检测。
> 核心排查口诀：**查进程、查网络、查定时任务、查日志、查账号、查文件。**

---

## 排查前准备

### 比喻

> Linux 应急排查和 Windows 类似——先看"谁在跑"（进程），再看"谁连着"（网络），然后查"谁定时干活"（crontab），最后看"监控记录"（日志）。

### 工具准备

| 工具 | 用途 |
|------|------|
| **ps/netstat/ss** | 进程和网络排查（系统自带） |
| **lsof** | 查看进程打开的文件和端口 |
| **chkrootkit/rkhunter** | Rootkit 检测 |
| **LiME/avml** | 内存镜像抓取 |
| **sysdig** | 系统行为监控 |

⚠️ **重要：** 排查前先确认系统中的 `ps`、`netstat`、`ss`、`ls` 等命令没被替换。攻击者可能用恶意版本替换系统命令隐藏自己。可以用 `rpm -V` 或 `debsums` 验证。

---

## 一、查进程

### 排查命令

```bash
# 查看所有进程
ps aux
ps -ef

# 查看进程树（看父子关系）
pstree -ap

# 按 CPU 排序（找挖矿）
top -b -n 1 | head -20

# 按内存排序
top -b -n 1 -o %MEM | head -20

# 查看进程的可执行文件路径
ls -l /proc/*/exe 2>/dev/null

# 查看进程的命令行
cat /proc/*/cmdline 2>/dev/null | tr '\0' ' '

# 查看进程的工作目录
ls -l /proc/*/cwd 2>/dev/null

# 查找已删除但仍被进程占用的文件（可能是恶意程序删除自身）
ls -l /proc/*/exe 2>/dev/null | grep "(deleted)"
```

### 什么进程是可疑的？

| 特征 | 说明 |
|------|------|
| **CPU 长期 100%** | 可能是挖矿程序 |
| **名字异常** | 随机字符串、仿冒系统进程（如 `[kworker]` 带括号伪装内核线程） |
| **路径异常** | 在 /tmp、/dev/shm、/var/tmp 等临时目录 |
| **exe 标记 deleted** | 进程文件被删除但进程还在运行（删除自身隐藏） |
| **网络外连** | 连接到未知外部 IP |

💡 小白提示：`ls -l /proc/*/exe 2>/dev/null | grep "(deleted)"` 是经典排查命令——恶意程序启动后删除自身文件，但进程还在运行，这条命令能把它揪出来。

### 进程排查思路

1. `ps aux` 找 CPU/内存异常的
2. `ls -l /proc/*/exe` 找路径异常的
3. 找到可疑 PID → `ls -l /proc/PID/exe` 看可执行文件路径
4. `cat /proc/PID/cmdline` 看启动命令
5. `ls -l /proc/PID/fd` 看打开的文件
6. `cat /proc/PID/maps` 看内存映射（是否注入了恶意代码）

---

## 二、查网络

### 排查命令

```bash
# 查看所有网络连接
netstat -tunlp
ss -tunlp

# 查看所有连接（包括已建立的）
netstat -tunap
ss -tunap

# 查看某个进程的网络连接
lsof -p PID -i

# 查看某个端口被谁占用
lsof -i :8080

# 查看所有网络连接及对应进程
lsof -i

# 查看路由表
route -n
ip route

# 查看 ARP 表
arp -a
ip neigh
```

### 什么连接是可疑的？

| 特征 | 说明 |
|------|------|
| **连到未知外部 IP** | 服务器不应主动连外部（可能 C2 回连） |
| **异常监听端口** | 开放了不该开的端口 |
| **非标准端口** | 4444、1337、31337 等常见后门端口 |
| **反弹 Shell** | 服务器主动连外部的某端口（反弹 Shell 特征） |

### 排查步骤

1. `ss -tunap` 导出所有连接
2. 找 ESTAB 状态的外部连接
3. `lsof -p PID` 找到对应进程
4. 判断该进程是否合法
5. 查威胁情报确认 IP 是否恶意

---

## 三、查定时任务（持久化）

### 比喻

> 查定时任务就像查"谁在你家装了定时开关"——Linux 上 crontab 是最常见的持久化方式。

### 排查命令

```bash
# 查看当前用户的定时任务
crontab -l

# 查看所有用户的定时任务
for user in $(cut -f1 -d: /etc/passwd); do crontab -u $user -l 2>/dev/null; done

# 查看系统级定时任务
cat /etc/crontab
ls -la /etc/cron.d/
ls -la /etc/cron.hourly/
ls -la /etc/cron.daily/
ls -la /etc/cron.weekly/
ls -la /etc/cron.monthly/

# 查看 at 定时任务
atq

# 查看 systemd timer
systemctl list-timers --all
```

### 其他持久化位置

```bash
# SSH 公钥后门
cat ~/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
for user in $(cut -f1 -d: /etc/passwd); do cat /home/$user/.ssh/authorized_keys 2>/dev/null; done

# 开机自启动服务
systemctl list-unit-files --state=enabled
chkconfig --list 2>/dev/null

# RC.local
cat /etc/rc.local
cat /etc/rc.d/rc.local

# Profile 和 bashrc（用户登录时执行）
cat /etc/profile
cat ~/.bashrc
cat ~/.bash_profile
cat /etc/bashrc

# LD_PRELOAD 劫持
cat /etc/ld.so.preload
env | grep LD_PRELOAD

# 动态链接库配置
cat /etc/ld.so.conf
cat /etc/ld.so.conf.d/*
```

💡 小白提示：`~/.ssh/authorized_keys` 是最常被忽略的后门——攻击者加一行 SSH 公钥，就能免密码登录。排查时一定要检查所有用户的 authorized_keys 文件。

---

## 四、查日志

### 比喻

> Linux 日志就像监控录像——`/var/log` 目录下存了各种系统活动的记录。

### 核心日志文件

| 日志文件 | 内容 | 比喻 |
|---------|------|------|
| `/var/log/auth.log` 或 `/var/log/secure` | 认证日志（登录/SSH/sudo） | 门禁记录 |
| `/var/log/syslog` 或 `/var/log/messages` | 系统日志 | 通用监控 |
| `/var/log/secure` | 安全相关日志 | 安保记录 |
| `/var/log/wtmp` | 登录记录（二进制） | 谁来过 |
| `/var/log/btmp` | 登录失败记录（二进制） | 谁试图闯入 |
| `/var/log/lastlog` | 最后登录记录（二进制） | 最后一次签到 |
| `/var/log/audit/audit.log` | 审计日志 | 详细操作记录 |
| `~/.bash_history` | 命令历史 | 个人操作记录 |
| `/var/log/nginx/access.log` | Web 访问日志 | 网站访客记录 |
| `/var/log/nginx/error.log` | Web 错误日志 | 网站异常记录 |

### 常用日志分析命令

```bash
# 查看最近登录成功记录
last

# 查看登录失败记录
lastb

# 查看当前登录用户
w
who

# 查看 SSH 登录成功
grep "Accepted" /var/log/auth.log
grep "Accepted" /var/log/secure

# 查看 SSH 登录失败（暴破检测）
grep "Failed password" /var/log/auth.log | head -20
grep "Failed password" /var/log/secure | head -20

# 查看暴破来源 IP 统计
grep "Failed password" /var/log/auth.log | awk '{print $(NF-3)}' | sort | uniq -c | sort -rn | head

# 查看 sudo 操作
grep "sudo" /var/log/auth.log

# 查看用户创建
grep "useradd" /var/log/auth.log

# 查看命令历史
cat ~/.bash_history
cat /root/.bash_history

# 检查命令历史是否被清空
wc -l ~/.bash_history
# 如果行数为 0 或文件被删除 = 可疑
```

### 日志分析要点

1. **异常登录时间** → 非工作时间的登录
2. **异常登录 IP** → 从未知 IP 登录
3. **暴破特征** → 短时间大量 Failed password
4. **命令历史清空** → 攻击者清除痕迹
5. **日志中断** → 某时间点日志突然断了
6. **异常 sudo** → 普通用户突然用 sudo

💡 小白提示：`/var/log/wtmp` 和 `btmp` 是二进制文件，不能直接 cat。用 `last` 和 `lastb` 命令查看。如果 `last` 显示的登录记录异常少，可能 wtmp 被清空了。

---

## 五、查账号

```bash
# 查看所有用户
cat /etc/passwd

# 查看 UID 为 0 的用户（只有 root 应该是 0）
awk -F: '$3==0 {print $1}' /etc/passwd

# 查看可登录用户
cat /etc/passwd | grep -v "nologin\|false" | grep -v "^#"

# 查看最近创建的用户
grep "useradd" /var/log/auth.log

# 查看 sudo 组成员
cat /etc/sudoers
cat /etc/sudoers.d/*

# 查看 SSH 配置
cat /etc/ssh/sshd_config | grep -E "PermitRootLogin|PasswordAuthentication|Port"
```

### 什么账号是可疑的？

- 新创建的用户
- UID 为 0 的非 root 用户（提权后门）
- 被加入 sudo/wheel 组的普通用户
- authorized_keys 中多出的公钥
- SSH 配置被修改（如允许 root 登录、改端口）

---

## 六、查文件

```bash
# 查找最近修改的文件（24 小时内）
find / -mtime -1 -type f 2>/dev/null | head -50

# 查找最近修改的文件（按分钟）
find / -mmin -60 -type f 2>/dev/null | head -50

# 查找 SUID 文件（可能用于提权）
find / -perm -4000 -type f 2>/dev/null

# 查找临时目录下的可执行文件
find /tmp /var/tmp /dev/shm -type f -executable 2>/dev/null

# 查找隐藏文件
find / -name ".*" -type f 2>/dev/null | head -50

# 查找大文件（可能是打包的数据外传）
find / -size +100M -type f 2>/dev/null | head -20
```

### 检查系统命令是否被替换

```bash
# RPM 系（CentOS/RHEL）
rpm -V coreutils
rpm -V procps
rpm -V net-tools

# DEB 系（Ubuntu/Debian）
debsums coreutils
debsums procps
debsums net-tools

# 对比命令大小和修改时间
ls -l /bin/ps /bin/ls /bin/netstat /usr/bin/ss
```

💡 小白提示：如果 `ps`、`netstat` 被替换了，你看到的结果就是假的——攻击者修改了这些命令隐藏自己的进程和连接。用 `rpm -V` 或 `debsums` 验证系统命令完整性。

---

## 七、Rootkit 检测

### chkrootkit

```bash
# 安装
apt install chkrootkit    # Debian/Ubuntu
yum install chkrootkit    # CentOS/RHEL

# 运行检测
chkrootkit

# 只看可疑结果
chkrootkit | grep -i "infected\|suspicious"
```

### rkhunter

```bash
# 安装
apt install rkhunter
yum install rkhunter

# 更新数据库
rkhunter --update

# 运行检测
rkhunter --check --sk

# 查看报告
cat /var/log/rkhunter.log | grep -i "warning\|infected"
```

### Rootkit 检测要点

- chkrootkit 和 rkhunter 都用，互相补充
- 检测结果有 Warning 不一定就是 Rootkit，需要人工判断
- 最可靠的 Rootkit 检测方法：离线分析（用可信 U 盘启动，扫描硬盘）

---

## Linux 应急排查 Checklist

```
□ 第 0 步：断网不断电，保现场
□ 确认系统命令未被替换（rpm -V / debsums）
□ 查进程：
  □ ps aux（找 CPU/内存异常）
  □ /proc/*/exe（找路径异常）
  □ grep "(deleted)"（找删除自身的进程）
□ 查网络：
  □ ss -tunap（找外部 ESTAB 连接）
  □ lsof -i（关联进程）
□ 查定时任务：
  □ crontab -l（所有用户）
  □ /etc/cron.*
  □ systemctl list-timers
□ 查持久化：
  □ ~/.ssh/authorized_keys（SSH 后门）
  □ systemctl list-unit-files（自启动服务）
  □ ~/.bashrc / /etc/profile（登录执行）
  □ /etc/ld.so.preload（LD_PRELOAD 劫持）
□ 查日志：
  □ last / lastb（登录记录）
  □ grep "Accepted\|Failed" /var/log/auth.log
  □ ~/.bash_history（命令历史）
  □ 检查日志是否被清空
□ 查账号：
  □ UID=0 的用户
  □ 新建用户
  □ sudo 组成员
□ 查文件：
  □ find -mtime -1（最近修改）
  □ find -perm -4000（SUID 提权）
  □ find /tmp /dev/shm（临时目录）
□ Rootkit 检测：
  □ chkrootkit
  □ rkhunter
□ 记录所有发现，形成排查报告
```
