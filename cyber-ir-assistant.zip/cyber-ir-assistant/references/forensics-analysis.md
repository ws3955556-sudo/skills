# 数字取证分析

> 本文件覆盖四大取证分析方向：日志分析、内存取证、磁盘取证、网络取证，以及时间线还原方法。
> 核心理念：**取证不是"找到恶意程序"就完了，而是"还原攻击者做了什么、什么时候做的、怎么做的"。**

---

## 一、日志分析

### 比喻

> 日志分析就像看监控录像回放——攻击者的每一步操作都可能留有日志记录，你的任务是把碎片化的日志拼成完整的攻击时间线。

### 日志分析三步法

```
1. 收集 → 把所有相关日志汇总（系统日志/应用日志/安全设备日志）
2. 过滤 → 按时间范围和关键词缩小范围
3. 关联 → 把不同日志源的事件按时间线关联起来
```

### Windows 日志分析

#### 核心日志源

| 日志 | 位置 | 内容 |
|------|------|------|
| Security | 事件查看器 | 登录/权限/账号变更 |
| System | 事件查看器 | 系统事件/服务 |
| Application | 事件查看器 | 应用程序 |
| PowerShell | 事件查看器 | PowerShell 操作 |
| IIS | `%SystemDrive%\inetpub\logs` | Web 访问 |
| RDP | 事件查看器 Security | 远程桌面 |

#### 关键事件 ID 速查

| 事件 ID | 含义 | 排查价值 |
|---------|------|---------|
| 4624 | 登录成功 | 找异常时间/异常 IP 登录 |
| 4625 | 登录失败 | 找暴力破解 |
| 4634 | 注销 | 辅助时间线 |
| 4672 | 管理员登录 | 找权限提升 |
| 4688 | 进程创建 | 找恶意程序执行 |
| 4720 | 用户创建 | 找后门账号 |
| 4732 | 用户加入组 | 找提权 |
| 7045 | 服务安装 | 找后门服务 |
| 7036 | 服务状态变更 | 辅助时间线 |

#### PowerShell 日志分析

```powershell
# 启用 PowerShell 脚本块日志（如果没开）
# 组策略 → 计算机配置 → 管理模板 → Windows PowerShell → 启用脚本块日志

# 查看 PowerShell 脚本块日志
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational'; Id=4104} |
  Select-Object TimeCreated,Message -First 50

# 查找含危险命令的 PowerShell 操作
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational'; Id=4104} |
  Where-Object {$_.Message -match "DownloadString|Invoke-Expression|IEX|WebClient|DownloadFile"} |
  Select-Object TimeCreated,Message
```

💡 小白提示：攻击者大量使用 PowerShell（无文件攻击），所以 PowerShell 日志是取证重点。`Invoke-Expression`（IEX）、`DownloadString` 是典型的恶意下载执行特征。

### Linux 日志分析

#### 核心命令

```bash
# 按时间范围过滤
awk -v d1="2024-01-01 10:00:00" -v d2="2024-01-01 12:00:00" '$0 >= d1 && $0 <= d2' /var/log/auth.log

# 统计登录失败 IP Top 10
grep "Failed password" /var/log/auth.log | awk '{print $(NF-3)}' | sort | uniq -c | sort -rn | head -10

# 查看某 IP 的所有操作
grep "192.168.1.100" /var/log/auth.log

# 查看 root 用户操作历史
grep "root" /var/log/auth.log

# 统计每个用户登录次数
last | awk '{print $1}' | sort | uniq -c | sort -rn

# 查找 sudo 操作
grep "sudo" /var/log/auth.log | grep "COMMAND"

# Web 日志分析：统计访问最多的 URL
awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -20

# Web 日志分析：统计访问最多的 IP
awk '{print $1}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -20

# Web 日志分析：查找 SQL 注入特征
grep -E "union|select|sleep|benchmark|concat" /var/log/nginx/access.log

# Web 日志分析：查找目录遍历
grep -E "\.\./\.\./" /var/log/nginx/access.log

# Web 日志分析：查找 Webshell 访问
grep -E "POST.*\.(php|jsp|asp)" /var/log/nginx/access.log | awk '{print $7}' | sort | uniq -c | sort -rn
```

### 日志关联分析

当事件涉及多台机器时，需要把不同来源的日志按时间线关联：

```
10:00:00  攻击者通过 Web 漏洞上传 Webshell（Web 服务器 access.log）
10:01:00  Webshell 执行 whoami（Web 服务器 进程日志）
10:02:00  Webshell 创建新用户（Web 服务器 Security 4720）
10:03:00  攻击者用新用户 SSH 登录（Web 服务器 auth.log "Accepted"）
10:05:00  攻击者通过 SSH 登录到数据库服务器（数据库服务器 auth.log "Accepted"）
10:06:00  攻击者执行 mysqldump 导出数据（数据库服务器 bash_history）
10:08:00  攻击者通过 scp 传出数据（数据库服务器 bash_history + 网络流量）
```

💡 小白提示：日志关联时注意时区！不同服务器可能时区不同，先统一时区再关联，否则时间线会乱。

---

## 二、内存取证

### 比喻

> 内存取证就像拍了一张"案发现场"的照片——内存里存着当前运行的进程、网络连接、密码、注册表等实时信息。关机就没了，所以必须趁活着抓。

### 为什么需要内存取证

| 内存里有 | 磁盘上没有 |
|---------|-----------|
| 运行中的恶意进程 | （可能只存在内存中，无文件落地） |
| 当时的网络连接 | （连接是动态的） |
| 明文密码/密钥 | （密码在内存中可能是明文） |
| 注入代码 | （注入到合法进程内存中） |
| 加密的解密密钥 | （运行时密钥在内存中） |

### 抓取内存镜像

```bash
# Windows - WinPMEM
winpmem_mini_x64.exe memdump.dmp

# Windows - DumpIt（双击运行）
DumpIt.exe

# Linux - LiME
insmod lime.ko "path=memdump.lime format=lime"

# Linux - avml（无需内核模块）
avml memdump.lime
```

### Volatility 分析（详见 cyber-tool-master 的 forensics-tools.md）

```bash
# Volatility 3
vol.py -f memdump.dmp windows.pslist       # 进程列表
vol.py -f memdump.dmp windows.psscan       # 隐藏进程检测
vol.py -f memdump.dmp windows.netstat      # 网络连接
vol.py -f memdump.dmp windows.hashdump     # 密码哈希
vol.py -f memdump.dmp windows.malfind      # 代码注入检测
vol.py -f memdump.dmp windows.cmdline      # 进程命令行
vol.py -f memdump.dmp windows.registry.hivelist  # 注册表
```

### 内存取证分析要点

1. **对比 pslist 和 psscan** → 找隐藏进程（Rootkit 隐藏）
2. **找异常父子关系** → 如 `cmd.exe` 的父进程是 `spoolsv.exe`（打印服务不应该启动命令行）
3. **找注入代码** → `malfind` 检测哪段内存有可执行权限但不是正常模块
4. **提取网络连接** → 找 C2 回连
5. **提取密码** → `hashdump` 获取 NTLM 哈希

---

## 三、磁盘取证

### 比喻

> 磁盘取证就像对案发现场做"全景拍照"——把整个硬盘逐字节复制下来，然后在副本上分析，不破坏原始证据。

### 取证原则

1. **只读挂载** → 原始磁盘用只读方式挂载，防止修改
2. **哈希校验** → 取证镜像做 MD5/SHA256 校验，确保完整性
3. **副本分析** → 在副本上操作，不动原始证据
4. **操作留痕** → 记录每一步操作

### 制作磁盘镜像

```bash
# 使用 dd（基础工具）
dd if=/dev/sda of=disk_image.dd bs=4M conv=sync,noerror

# 使用 dcfldd（带哈希校验的 dd）
dcfldd if=/dev/sda of=disk_image.dd hash=md5,sha256 hashlog=hashes.txt

# 使用 FTK Imager（Windows GUI 工具）
# File → Create Disk Image → 选择源磁盘 → 选择镜像格式（E01/raw）
```

### 磁盘分析工具

| 工具 | 功能 |
|------|------|
| **Autopsy** | GUI 取证分析（文件恢复/时间线/关键词搜索） |
| **The Sleuth Kit** | Autopsy 的命令行后端 |
| **FTK Imager** | 磁盘镜像制作和预览 |
| **foremost** | 文件雕刻（从镜像中提取文件） |
| **binwalk** | 固件分析（扫描嵌入文件） |

### 磁盘分析要点

1. **恢复已删除文件** → Autopsy 文件列表中标红叉的是被删除但仍可恢复的
2. **时间线分析** → 按时间排序所有文件操作，找攻击时间窗口
3. **关键词搜索** → 搜索攻击者可能留下的关键词（如 `password`、攻击者用户名）
4. **文件类型识别** → 按文件签名识别真实类型（不只看扩展名）
5. **哈希比对** → 与已知恶意文件哈希库比对
6. **提取嵌入文件** → foremost/binwalk 从镜像中提取隐藏文件

---

## 四、网络取证

### 比喻

> 网络取证就像调取高速公路的监控——谁去了哪、什么时候去的、带了什么东西，网络流量里都有记录。

### 全流量抓取

```bash
# tcpdump 全流量抓包
tcpdump -i eth0 -w full_traffic.pcap

# 限定抓包大小（避免文件过大）
tcpdump -i eth0 -w full_traffic.pcap -C 100 -W 50
# -C 100：每个文件 100MB
# -W 50：最多 50 个文件（循环覆盖）
```

### 流量分析要点

1. **找 C2 通信** → 服务器主动连外部的连接（可能是 beacon 回连）
2. **找数据外传** → 大量外传流量（可能是数据泄露）
3. **找扫描行为** → 一台机器对多个 IP 的端口扫描
4. **找恶意下载** → 从已知恶意 IP 下载文件
5. **DNS 分析** → 异常 DNS 查询（DNS 隧道、DGA 域名）

### Wireshark 流量分析

```
# 过滤 C2 通信（服务器主动外连）
tcp.flags.syn==1 && tcp.flags.ack==0 && ip.src==192.168.1.100 && ip.dst!=192.168.1.0/24

# 过滤 HTTP POST（可能是数据外传或 Webshell 操作）
http.request.method == "POST"

# 过滤大流量传输
tcp.len > 1000

# 追踪完整对话
右键 → Follow → TCP Stream

# 提取传输的文件
File → Export Objects → HTTP
```

### DNS 分析

```bash
# 从 pcap 中提取 DNS 查询
tshark -r traffic.pcap -Y "dns.qry.name" -T fields -e dns.qry.name | sort | uniq -c | sort -rn

# 查找异常长域名（可能是 DNS 隧道）
tshark -r traffic.pcap -Y "dns.qry.name" -T fields -e dns.qry.name | awk '{if(length($0)>50) print $0}'

# 查找 DGA 域名特征（随机字符）
tshark -r traffic.pcap -Y "dns.qry.name" -T fields -e dns.qry.name | grep -E "^[a-z0-9]{8,}\.com$"
```

💡 小白提示：DNS 隧道是攻击者常用的隐蔽通信方式——把数据编码到 DNS 查询的子域名里。特征是大量超长子域名查询，如 `aGVsbG8gd29ybGQ=.tunnel.evil.com`。

---

## 五、时间线还原

### 比喻

> 时间线还原就像拼拼图——把不同来源的证据（日志/内存/磁盘/流量）按时间排列，拼出攻击者"什么时候做了什么"的完整故事。

### 时间线还原步骤

1. **确定事件时间窗口** → 从首次告警/异常时间点往前推
2. **收集所有时间相关证据** → 系统日志/应用日志/网络流量/文件时间戳
3. **统一时区** → 所有时间戳转为同一时区
4. **按时间排序** → 从最早到最晚排列所有事件
5. **标注关键节点** → 入侵点/提权/横移/数据外传/清除痕迹
6. **补充缺失环节** → 根据已有证据推断可能的行为

### 时间线模板

```
## 攻击时间线

### 准备阶段
| 时间 | 事件 | 证据来源 |
|------|------|---------|
| ??-?? 10:00 | 攻击者扫描目标端口 | 防火墙日志 |
| ??-?? 10:05 | 攻击者发现 80 端口开放 | Nmap 日志（攻击者机器） |

### 入侵阶段
| 时间 | 事件 | 证据来源 |
|------|------|---------|
| ??-?? 10:10 | 攻击者利用文件上传漏洞上传 Webshell | Web access.log |
| ??-?? 10:11 | Webshell 首次执行 whoami | Web 服务器进程日志 |

### 横移阶段
| 时间 | 事件 | 证据来源 |
|------|------|---------|
| ??-?? 10:15 | 攻击者通过 Webshell 抓取密码 | 进程日志（Mimikatz） |
| ??-?? 10:20 | 攻击者用抓到的密码 SSH 到数据库服务器 | auth.log "Accepted" |

### 目标达成
| 时间 | 事件 | 证据来源 |
|------|------|---------|
| ??-?? 10:25 | 攻击者执行 mysqldump 导出数据 | bash_history |
| ??-?? 10:28 | 攻击者 scp 传出数据 | 网络流量 |

### 清理阶段
| 时间 | 事件 | 证据来源 |
|------|------|---------|
| ??-?? 10:30 | 攻击者清除 bash_history | bash_history 文件大小为 0 |
| ??-?? 10:32 | 攻击者清除 Web 日志 | access.log 在此时间点后中断 |
```

### 时间线分析技巧

1. **从告警时间往前推** → 攻击者通常在告警前已经活动了一段时间
2. **注意时间差** → 两个事件之间的时间差能推断攻击者是否手动操作（慢）还是自动化（快）
3. **关注"消失的时间"** → 日志中断的时间段，可能是攻击者在清除痕迹
4. **交叉验证** → 同一事件在多个日志源中都有记录，可信度更高
5. **推断未记录的行为** → 如果 A→C 之间有 B 的痕迹，即使 B 没有日志，也可能发生过

---

## 六、IOC 提取与分享

### 比喻

> IOC 就像犯罪嫌疑人的"指纹"——攻击者留下的特征信息，用来在其他系统中搜索是否也被攻击。

### 常见 IOC 类型

| 类型 | 示例 |
|------|------|
| **IP 地址** | C2 服务器 IP、攻击源 IP |
| **域名** | 恶意域名、钓鱼域名 |
| **文件哈希** | 恶意文件的 MD5/SHA256 |
| **文件路径** | Webshell 路径、恶意程序路径 |
| **注册表键** | 持久化注册表项 |
| **网络特征** | C2 通信端口、User-Agent |
| **行为特征** | 执行的命令、创建的服务名 |

### IOC 提取方法

```bash
# 从日志提取攻击 IP
grep "Failed password" /var/log/auth.log | awk '{print $(NF-3)}' | sort -u

# 从内存提取网络连接（C2 IP）
vol.py -f memdump.dmp windows.netstat | grep ESTAB

# 提取恶意文件哈希
sha256sum /tmp/malware

# 从流量提取 C2 域名
tshark -r traffic.pcap -Y "dns.qry.name" -T fields -e dns.qry.name | sort -u

# 从 Webshell 提取特征
grep -n "eval\|system\|exec" /var/www/html/shell.php
```

### IOC 分享格式

STIX/TAXII 是标准 IOC 分享格式。简单的 IOC 清单也可以用 CSV：

```csv
type,value,description,confidence
ip,192.168.1.100,C2 服务器,high
domain,evil.example.com,钓鱼域名,high
hash,abc123...,恶意文件 SHA256,medium
```
