# Windows 应急响应排查

> 本文件覆盖 Windows 系统应急响应排查全流程：进程、网络、启动项、服务、日志、注册表、用户账号。
> 核心排查口诀：**查进程、查网络、查启动项、查日志、查账号、查文件。**

---

## 排查前准备

### 比喻

> Windows 应急排查就像医生问诊——先看生命体征（进程/网络），再查病史（日志），最后做专项检查（启动项/服务/注册表）。

### 工具准备

| 工具 | 用途 | 来源 |
|------|------|------|
| **Process Explorer** | 进程分析（比任务管理器强） | Sysinternals |
| **Process Monitor** | 实时监控进程行为 | Sysinternals |
| **Autoruns** | 查看所有自启动项 | Sysinternals |
| **TCPView** | 实时网络连接查看 | Sysinternals |
| **WinPMEM** | 内存镜像抓取 | 开源 |
| **PowerShell** | 命令行排查 | 系统自带 |

💡 小白提示：Sysinternals 套件是 Windows 应急响应必备，建议平时下载放到 U 盘里。下载地址：[learn.microsoft.com/sysinternals](https://learn.microsoft.com/sysinternals/)

---

## 一、查进程

### 比喻

> 查进程就像查"谁在你家干活"——正常的是家人（系统进程），可疑的是陌生人（恶意进程）。

### 排查命令

```powershell
# 查看所有进程
tasklist /v

# 查看进程及对应可执行文件路径
wmic process get name,processid,executablepath

# 查看进程的命令行参数（重要！能看到恶意程序带了什么参数）
wmic process get name,processid,commandline

# PowerShell 查看进程及路径
Get-Process | Select-Object Name,Id,Path | Format-Table -AutoSize

# 查看进程父子关系（看谁启动了谁）
Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId

# 查找没有数字签名或签名异常的进程
Get-Process | Where-Object {$_.Path} | ForEach-Object {
    $sig = Get-AuthenticodeSignature $_.Path
    if ($sig.Status -ne "Valid") { Write-Output "$($_.Name) - $($_.Path) - $($sig.Status)" }
}
```

### 什么进程是可疑的？

| 特征 | 说明 |
|------|------|
| **路径异常** | 系统进程不在系统目录（如 `svchost.exe` 在 `C:\Users\` 下） |
| **名字仿冒** | 伪装系统进程名（如 `svch0st.exe`、`scvhost.exe`） |
| **无签名** | 没有数字签名或签名异常 |
| **CPU/内存异常** | 长期占用高 CPU（可能是挖矿）、异常高内存 |
| **网络外连** | 连接到未知外部 IP（可能是 C2 回连） |
| **父进程异常** | 系统进程的父进程不是 services.exe（可能被注入） |

💡 小白提示：`svchost.exe` 是最常被伪装的进程名。正常的 svchost.exe 在 `C:\Windows\System32\` 下，且父进程是 `services.exe`。如果在别的目录发现 svchost.exe，大概率是恶意程序。

### 用 Process Explorer 深入分析

1. 下载 Process Explorer → 以管理员身份运行
2. View → Select Columns → 勾选 "Image Path"、"Command Line"、"Verified Signer"
3. 按可疑特征排序：
   - 看 Image Path 列，找路径异常的
   - 看 Verified Signer 列，找没有签名的
   - 看命令行列，找带奇怪参数的
4. 右键可疑进程 → Properties → 看 TCP/IP 标签（网络连接）、Strings 标签（内嵌字符串）

---

## 二、查网络

### 比喻

> 查网络就像查"谁在跟你家通电话"——正常的是家人朋友（合法连接），可疑的是陌生人（C2 回连）。

### 排查命令

```powershell
# 查看所有网络连接
netstat -ano

# 只看 TCP 连接
netstat -ano -p tcp

# 只看 LISTENING 状态（开放端口）
netstat -ano | findstr LISTENING

# 查看外部连接（ESTABLISHED 状态）
netstat -ano | findstr ESTABLISHED

# 查看某个 PID 的网络连接
netstat -ano | findstr "1234"
```

### 什么连接是可疑的？

| 特征 | 说明 |
|------|------|
| **连到未知外部 IP** | 服务器不应主动连外部 IP（可能是 C2 回连） |
| **非标准端口通信** | 如 4444、1337、8080 等常见后门端口 |
| **大量 DNS 查询** | 可能是 DNS 隧道或 C2 通信 |
| **异常监听端口** | 开放了不该开放的端口 |
| **跨国连接** | 连接到与业务无关的境外 IP |

### 排查步骤

1. `netstat -ano` 导出所有连接
2. 找出 ESTABLISHED 状态的外部连接
3. 用 `tasklist | findstr PID` 找到对应进程
4. 判断该进程是否合法
5. 用威胁情报平台查询目标 IP 是否恶意（如 VirusTotal、微步在线）

---

## 三、查启动项（持久化）

### 比喻

> 查启动项就像查"谁在你家装了定时开关"——攻击者设置开机自启动，重启后后门还在。

### 排查命令

```powershell
# 查看注册表启动项
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"

# 查看启动文件夹
dir "C:\Users\*\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\"
dir "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\"

# 查看计划任务
schtasks /query /fo TABLE /v

# 查看服务
sc query state= all
```

### 用 Autoruns 全量排查

Autoruns 能看到**所有**自启动位置（注册表、启动文件夹、服务、计划任务、浏览器插件、Office 宏等 50+ 个位置）。

1. 下载 Autoruns → 以管理员身份运行
2. Options → 勾选 "Hide Microsoft Entries"（隐藏微软官方项）
3. 剩下的非微软项就是重点关注对象
4. 检查每个项的路径和签名
5. 右键可疑项 → "Search VirusTotal"（上传到 VirusTotal 检测）

### 常见持久化位置

| 位置 | 比喻 |
|------|------|
| `HKLM\...\Run` | 注册表启动项（全局） |
| `HKCU\...\Run` | 注册表启动项（当前用户） |
| 启动文件夹 | 开机自动运行的快捷方式 |
| 计划任务 | 定时执行的后门 |
| Windows 服务 | 后台自启动的服务 |
| WMI 事件订阅 | 高级持久化（难发现） |
| DLL 劫持 | 替换合法 DLL 加载恶意代码 |
| 映像劫持（IFEO） | 注册表劫持程序启动 |

💡 小白提示：WMI 事件订阅是最隐蔽的持久化方式之一，Autoruns 能检测到。排查时不要只看 Run 键和启动文件夹。

---

## 四、查服务

```powershell
# 列出所有服务
sc query state= all

# 查看服务详情
sc qc "服务名"

# 查看服务可执行文件路径
sc qc "服务名" | findstr BINARY_PATH_NAME

# PowerShell 查看服务
Get-Service | Where-Object {$_.Status -eq "Running"} | Format-Table -AutoSize
```

### 什么服务是可疑的？

- 服务名随机/无意义（如 `abcxyz`）
- 可执行文件路径在临时目录或用户目录
- 服务描述为空或异常
- 服务对应的可执行文件没有数字签名

---

## 五、查日志

### 比喻

> 查日志就像查"监控录像"——攻击者的每一步操作都可能留有日志记录。

### Windows 核心日志

| 日志 | 事件 ID | 说明 |
|------|---------|------|
| Security | 4624 | 登录成功 |
| Security | 4625 | 登录失败（暴力破解） |
| Security | 4720 | 创建用户 |
| Security | 4732 | 用户被加入组（提权） |
| Security | 4688 | 进程创建 |
| System | 7045 | 新服务安装（可能后门） |
| System | 7036 | 服务停止/启动 |
| Application | - | 应用程序日志 |
| PowerShell | 4104 | PowerShell 脚本块日志 |

### 用事件查看器排查

```powershell
# 查看登录失败日志（暴力破解检测）
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625} | Select-Object TimeCreated,Message -First 20

# 查看登录成功日志
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624} | Select-Object TimeCreated,Message -First 20

# 查看新创建的用户
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4720} | Select-Object TimeCreated,Message

# 查看新安装的服务
Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045} | Select-Object TimeCreated,Message

# 导出日志
wevtutil epl Security C:\security.evtx
```

### 日志分析要点

1. **登录时间** → 非工作时间的登录是否合法？
2. **登录来源** → 从未知 IP 登录？
3. **登录类型** → 类型 3（网络登录）、类型 10（远程桌面）是否正常？
4. **失败次数** → 短时间大量失败 = 暴力破解
5. **日志清除** → 安全日志突然中断 = 攻击者清日志

💡 小白提示：攻击者入侵后经常清除日志。如果发现日志在某个时间点突然断了，那个时间点可能就是攻击者操作的时间。

---

## 六、查账号

```powershell
# 查看所有用户
net user

# 查看用户详情
net user 用户名

# 查看管理员组
net localgroup administrators

# 查看隐藏用户（用户名以 $ 结尾的）
reg query "HKLM\SAM\SAM\Domains\Account\Users"
```

### 什么账号是可疑的？

- 新创建的用户账号
- 被加入管理员组的普通用户
- 用户名以 `$` 结尾的隐藏账号
- 被启用的 Guest 账号

---

## 七、查文件

```powershell
# 查找最近修改的文件
Get-ChildItem C:\ -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.LastWriteTime -gt (Get-Date).AddDays(-1)} | Select-Object FullName,LastWriteTime

# 查找 Web 目录下的 Webshell
Get-ChildItem "C:\inetpub\wwwroot" -Recurse -Include *.asp,*.aspx,*.php,*.jsp | Select-Object FullName,LastWriteTime

# 查找临时目录下的可执行文件
Get-ChildItem $env:TEMP -Recurse -Include *.exe,*.dll,*.bat,*.ps1 | Select-Object FullName
```

### Webshell 检测

| 特征 | 说明 |
|------|------|
| Web 目录下新文件 | 最近创建的脚本文件 |
| 文件名异常 | 如 `cmd.asp`、`shell.php`、`1.php` |
| 内容含危险函数 | `eval`、`system`、`exec`、`shell_exec` |
| 文件大小异常 | Webshell 通常很小（1-10KB） |

---

## Windows 应急排查 Checklist

```
□ 第 0 步：断网不断电，保现场（截图/存日志/抓内存）
□ 查进程：tasklist / wmic process / Process Explorer
  □ 找路径异常的
  □ 找名字仿冒的
  □ 找无签名的
  □ 找 CPU 异常的
□ 查网络：netstat -ano
  □ 找外部 ESTABLISHED 连接
  □ 关联到进程
  □ 查 IP 威胁情报
□ 查启动项：Autoruns（隐藏微软项）
  □ 注册表 Run 键
  □ 启动文件夹
  □ 计划任务
  □ WMI 事件订阅
□ 查服务：sc query / Get-Service
  □ 找路径异常的服务
  □ 找无签名的服务
□ 查日志：事件查看器
  □ 4625（登录失败/暴破）
  □ 4624（登录成功/异常登录）
  □ 4720（新建用户）
  □ 7045（新服务）
  □ 日志中断（清日志）
□ 查账号：net user
  □ 新建账号
  □ 隐藏账号（$ 结尾）
  □ 管理员组变动
□ 查文件：
  □ 最近修改的文件
  □ Web 目录 Webshell
  □ 临时目录可执行文件
□ 记录所有发现，形成排查报告
```
