# 实验环境搭建指南

> 本文件是小白搭建网络安全实验环境的"保姆级教程"。所有环境仅限本地或授权实验，严禁用于真实系统。

## 零、先搞懂几个概念

**什么是靶场？**
> 靶场就是"故意留下漏洞供你练习的网站/系统"。就像消防演习用的模拟楼——故意留了各种"安全隐患"，让消防员在安全环境里练习。你可以在靶场里随便"攻击"，不用担责。

**什么是 Kali Linux？**
> Kali 是一个预装了数百个安全工具的 Linux 系统。就像程序员的"瑞士军刀"——你做安全实验需要的工具它基本都有，不用自己一个个装。它是安全从业者的标准"工作台"。

**什么是攻击机和靶机？**
> 攻击机 = 你操作的电脑（装了 Kali，上面有各种工具）
> 靶机 = 你要"攻击"的目标（故意有漏洞的系统，比如 DVWA）
> 两者放在同一个隔离的网络里，互不通外网。

**什么是 Burp Suite？**
> Burp Suite 是 Web 安全最常用的"抓包改包工具"。它像一个"中间人"——你的浏览器发请求，先经过 Burp，你可以看、改、重发这个请求。做 Web 实验必备。

## 一、实验环境架构原则

### 网络隔离铁律

> 💡 **小白先理解这个比喻：** 你做实验就像在"密室"里做——攻击机和靶机关在一个不通外网的房间里。靶机有漏洞，如果连了外网，外面真正的黑客可能反过来打你的靶机——所以必须隔离。

```
┌─────────────────────────────────────────────┐
│              宿主机 (Host)                    │
│                                             │
│  ┌───────────┐         ┌───────────────┐   │
│  │ 攻击机     │         │   靶机         │   │
│  │ Kali Linux │◄───────►│ DVWA/Meta...  │   │
│  │            │  仅主机  │               │   │
│  └───────────┘  网络/    └───────────────┘   │
│                 NAT网络                       │
│                                             │
│  ⚠️ 靶机绝不可直接暴露到公网                    │
│  ⚠️ 靶机不可接入生产网络                        │
│  ⚠️ 攻击机与靶机在同一隔离网络                   │
└─────────────────────────────────────────────┘
```

**三种隔离方案：**

| 方案 | 网络模式 | 适用场景 | 安全等级 |
|------|---------|---------|---------|
| 仅主机（Host-Only） | 攻击机↔靶机互通，不连外网 | 纯内网实验 | ★★★★★ |
| NAT 网络 | 攻击机↔靶机互通，可出网下载工具 | 需要联网安装环境 | ★★★★ |
| 桥接模式 | ❌ 不推荐 | — | ★★（有风险） |

**推荐：** 使用 Host-Only 或自定义 NAT 网络，将攻击机和靶机放在同一虚拟网络中，与宿主机生产网络隔离。

### VMware / VirtualBox 网络配置

**VMware：**
1. 编辑 → 虚拟网络编辑器 → 添加 VMnet（仅主机模式）
2. 攻击机和靶机网络适配器都选这个 VMnet
3. 禁用此 VMnet 的 DHCP（可选，手动配 IP 更稳定）

**VirtualBox：**
1. 管理 → 主机网络管理器 → 创建（vboxnet0）
2. 攻击机和靶机网卡设置为"仅主机(Host-Only) Adapter"，选 vboxnet0

---

## 二、Kali Linux 攻击机配置

### 安装方式

| 方式 | 优点 | 缺点 |
|------|------|------|
| VMware/VirtualBox 虚拟机 | 完整体验，隔离性好 | 占资源 |
| WSL2 + Kali | 轻量，与 Windows 共存 | 部分工具不支持 |
| Docker | 启动快，环境干净 | 网络配置复杂 |
| 物理机安装 | 性能最好 | 不推荐（安全风险） |

**推荐：** VMware/VirtualBox 虚拟机，分配 4GB+ 内存、2核+ CPU、30GB+ 磁盘。

### Kali 初始化配置

```bash
# 更新系统
sudo apt update && sudo apt full-upgrade -y

# 安装常用工具（部分可能未预装）
sudo apt install -y \
  dirb dirbuster gobuster \
  wordlists \
  hydra \
  nikto \
  whatweb \
  wpscan \
  commix \
  sqlmap \
  burpsuite \
  wireshark \
  nmap \
  masscan \
  crackmapexec

# 启用 PostgreSQL（Metasploit 依赖）
sudo systemctl enable postgresql
sudo systemctl start postgresql

# 初始化 Metasploit 数据库
sudo msfdb init

# 配置 Burp Suite（社区版）
# 1. 浏览器代理设为 127.0.0.1:8080
# 2. 安装 CA 证书：浏览器访问 http://burp/cert 下载并导入
```

### 常用字典位置

```bash
# Kali 自带字典
/usr/share/wordlists/           # 字典目录
/usr/share/wordlists/rockyou.txt  # 经典密码字典（需解压）
/usr/share/seclists/            # SecLists 字典集（需安装: apt install seclists）
```

---

## 三、经典 Web 靶场

### 1. DVWA（Damn Vulnerable Web App）

**定位：** Web 漏洞入门靶场，涵盖 SQLi / XSS / CSRF / 文件上传 / 命令注入等十余类漏洞，分 low/medium/high/impossible 四级难度。

**搭建方式：**

```bash
# 方式一：Docker（推荐，最简单）
docker run -d -p 8080:80 \
  --name dvwa \
  vulnerables/web-dvwa

# 访问：http://localhost:8080
# 默认账号：admin / password

# 方式二：直接部署在 Kali 上
sudo apt install -y apache2 php php-mysqli mariadb-server
sudo systemctl start apache2 mariadb
sudo mysql -e "CREATE DATABASE dvwa; CREATE USER 'dvwa'@'localhost' IDENTIFIED BY 'p@ssw0rd'; GRANT ALL ON dvwa.* TO 'dvwa'@'localhost';"
# 下载 DVWA 源码到 /var/www/html/dvwa/
# 配置 config/config.inc.php 数据库连接
sudo chown -R www-data:www-data /var/www/html/dvwa/
# 访问 http://localhost/dvwa/setup.php 初始化
```

**安全等级说明：**

| 等级 | 特点 | 学习目标 |
|------|------|---------|
| Low | 无任何防护 | 理解漏洞原始形态 |
| Medium | 基础防护 | 学习基本绕过技巧 |
| High | 较强防护 | 学习进阶绕过 |
| Impossible | 安全实现 | 学习正确防御代码 |

> **实验方法论：** 先 Low 理解原理 → Medium 学绕过 → High 练进阶 → Impossible 看正确写法。四级全做一遍才算掌握。

### 2. OWASP WebGoat

**定位：** OWASP 官方教学靶场，每节课先讲原理再让你动手，有课程进度跟踪。

```bash
# Docker 部署
docker run -d -p 8081:8080 -p 9090:9090 \
  --name webgoat \
  webgoat/goatandwolf

# 访问：http://localhost:8081/WebGoat
# 注册一个本地账号（数据不外传）
```

**特色：** 每个课程模块都有"提示"和"解决方案"按钮，适合自学。涵盖 Web 安全全谱系，比 DVWA 更系统。

### 3. OWASP Juice Shop

**定位：** 现代 Web 应用靶场，模拟一个在线果汁商店，包含 Angular + Node.js 技术栈。

```bash
# Docker 部署
docker run -d -p 3000:3000 \
  --name juice-shop \
  bkimminich/juice-shop

# 访问：http://localhost:3000
```

**特色：** 没有"课程目录"，而是给你一个商城首页，自己去发现漏洞。有内置的 Score Board 记录找到的漏洞。更接近真实渗透体验。

### 4. Pikachu 靶场

**定位：** 中文 Web 漏洞练习平台，中文界面友好，适合国内课程实验。

```bash
# Docker 部署
docker run -d -p 8082:80 \
  --name pikachu \
  area39/pikachu

# 访问：http://localhost:8082
```

**覆盖漏洞：** SQL注入 / XSS / CSRF / 文件包含 / 文件上传 / RCE / 越权 / 目录遍历 / 敏感信息泄露 / PHP反序列化 / XXE / SSRF / 逻辑漏洞。

### 5. sqli-labs

**定位：** SQL 注入专项练习，75 关从基础到高级。

```bash
# Docker 部署
docker run -d -p 8083:80 \
  --name sqli-labs \
  acgpiano/sqli-labs

# 访问：http://localhost:8083
```

**关卡设计：**

| 关卡范围 | 注入类型 | 难度 |
|---------|---------|------|
| 1-10 | 基础注入（GET） | ★★ |
| 11-16 | POST 注入 | ★★★ |
| 17-22 | Header 注入 | ★★★ |
| 23-37 | 绕过过滤 | ★★★★ |
| 38-53 | 堆叠注入 | ★★★★ |
| 54-75 | 盲注挑战 | ★★★★★ |

---

## 四、系统级靶场

### 1. Metasploitable 2

**定位：** 故意留下大量漏洞的 Linux 系统，用于练习 Nmap 扫描、服务漏洞利用、后渗透操作。

```bash
# 下载地址：https://sourceforge.net/projects/metasploitable/
# 解压后用 VMware/VirtualBox 打开
# 默认账号：msfadmin / msfadmin

# 网络配置：与 Kali 同一 Host-Only 网络
# 查看靶机 IP：登录后执行 ifconfig
```

**预装漏洞服务：**

| 端口 | 服务 | 漏洞类型 |
|------|------|---------|
| 21 | vsftpd | 后门 |
| 22 | SSH | 弱口令 |
| 23 | telnet | 弱口令 |
| 445 | Samba | usermap_script RCE |
| 1524 | bindshell | 后门 |
| 3306 | MySQL | 弱口令 |
| 5432 | PostgreSQL | 弱口令 |
| 6667 | IRC | UnrealIRCD 后门 |
| 8180 | Tomcat | 弱口令 + 部署 |
| 8787 | Ruby DRb | RCE |

### 2. Metasploitable 3

**定位：** Metasploitable 2 的升级版，分为 Ubuntu 和 Windows 两个版本，漏洞更现代。

```bash
# 需要用 Vagrant + Packer 构建
# 仓库：https://github.com/rapid7/metasploitable3
# 构建较复杂，建议参考官方文档
```

### 3. VulnHub 靶机

**定位：** 社区贡献的大量靶机，难度从入门到地狱级，模拟真实渗透场景。

**使用方式：**
1. 访问 https://www.vulnhub.com
2. 下载 .ova/.vmdk 文件
3. 导入虚拟机，配网络
4. 目标：获取 root 权限 + 读取 flag.txt

**推荐入门系列：**

| 靶机名 | 难度 | 考察点 |
|--------|------|--------|
| Kioptrix Level 1-5 | ★★ | Web漏洞 + 提权全流程 |
| Mr-Robot 1 | ★★★ | WordPress 渗透 |
| Stapler | ★★★ | 多服务枚举 + 利用 |
| DC Series (1-9) | ★★-★★★★ | Active Directory 渗透 |
| PwnLab Init | ★★★ | 文件包含 + 提权 |

### 4. HackTheBox / TryHackMe

**定位：** 在线靶场平台，无需本地搭建，有引导式学习路径。

| 平台 | 特点 | 适合 |
|------|------|------|
| TryHackMe | 有教程引导，适合入门 | 零基础~中级 |
| HackTheBox | 自由探索，难度较高 | 中级~高级 |
| PortSwigger Web Academy | Burp Suite 官方，Web 安全专精 | Web 方向 |

> **注意：** 这些平台是合法授权的练习环境，操作前仍需遵守平台规则。

---

## 五、Docker 靶场合集

### 一键搭建多靶场

```bash
# Vulhub —— 漏洞环境集合（基于 Docker-Compose）
git clone https://github.com/vulhub/vulhub.git
cd vulhub
# 每个漏洞目录下有 docker-compose.yml
# 启动指定漏洞环境：
cd flask/ssti
docker-compose up -d

# 查看端口映射
docker-compose ps
```

**Vulhub 特点：** 收录 500+ 已公开漏洞的复现环境，每个环境附带漏洞说明文档。适合漏洞复现学习。

### 常用 Docker 靶场速查

| 镜像名 | 说明 | 启动命令 |
|--------|------|---------|
| vulnerables/web-dvwa | DVWA | `docker run -d -p 80:80 vulnerables/web-dvwa` |
| bkimminich/juice-shop | Juice Shop | `docker run -d -p 3000:3000 bkimminich/juice-shop` |
| webgoat/goatandwolf | WebGoat | `docker run -d -p 8080:8080 -p 9090:9090 webgoat/goatandwolf` |
| acgpiano/sqli-labs | SQLi-Labs | `docker run -d -p 80:80 acgpiano/sqli-labs` |
| area39/pikachu | Pikachu | `docker run -d -p 80:80 area39/pikachu` |
| citizenstig/dvwa | DVWA（另一版本） | `docker run -d -p 80:80 citizenstig/dvwa` |

---

## 六、网络抓包与分析环境

### Burp Suite 配置

```
1. 代理设置
   - Proxy → Options → Proxy Listeners: 127.0.0.1:8080
   - 勾选 "Intercept Client Requests" 拦截请求

2. CA 证书安装（HTTPS 抓包必需）
   - 浏览器代理设为 127.0.0.1:8080
   - 访问 http://burp/cert → 下载 cacert.der
   - 浏览器导入为证书颁发机构（信任所有）

3. 常用模块
   - Proxy：拦截/修改请求响应
   - Repeater：重发请求（手工测试核心）
   - Intruder：自动化批量请求（暴破/fuzz）
   - Decoder：编码解码
   - Comparer：对比响应差异
```

### Wireshark 抓包

```bash
# Kali 中启动
sudo wireshark

# 常用过滤规则
tcp.port == 80              # HTTP 流量
tcp.port == 443             # HTTPS 流量
ip.addr == 192.168.1.100    # 指定 IP
http.request.method == "POST"  # POST 请求
http.response.code == 200   # 200 响应
tcp.flags.syn == 1          # SYN 包（扫描检测）
```

---

## 七、实验环境管理最佳实践

### 环境快照

```
⚠️ 每次实验前务必创建虚拟机快照！

VMware：虚拟机 → 快照 → 拍摄快照
VirtualBox：菜单 → 备份 → 生成备份

实验搞砸了？恢复快照，秒回干净状态。
```

### 环境清理

```bash
# Docker 靶场用完即删
docker stop <容器名>
docker rm <容器名>

# 或一键清理所有停止的容器
docker container prune

# 清理 Docker 镜像（释放磁盘）
docker image prune -a
```

### 安全检查清单

- [ ] 靶机网络是否隔离（Host-Only / 自定义 NAT）？
- [ ] 靶机是否暴露到公网？（必须否）
- [ ] 靶机是否接入生产网络？（必须否）
- [ ] 实验前是否创建了快照？
- [ ] 敏感信息（字典、工具配置）是否泄露到靶机外？
- [ ] 实验结束后是否清理了环境？
