# CTF 解题方法论

> 本文件是 CTF 小白入门的"学长笔记"。所有方法论限于合法 CTF 平台和授权训练环境。
>
> 核心理念：CTF 不是"黑客搞破坏"，而是"安全知识的安全竞技"——在合法平台上做题，学安全技术。

---

## CTF 是什么？（给完全没听过的人）

> CTF（Capture The Flag，夺旗赛）是网络安全圈的"数学竞赛"。
>
> 每道题给你一个"场景"（一个网站、一个程序、一个文件、一段加密数据），你的任务是找到藏在里面的 flag（一串特定格式的字符串，比如 `flag{y0u_g0t_1t}`）。
>
> 找到 flag 提交上去就得分的竞技比赛。全程在合法平台上进行，不需要也不会接触真实系统。

### CTF 比赛形式

| 形式 | 大白话 | 代表赛事 |
|------|--------|---------|
| 解题模式 | 像考试做题，各方向独立出题，做出来就得分 | CISCN、XCTF、DEF CON |
| 攻防模式 | 各队既要守自己的服务又要攻别人的，"下棋+下棋" | DEF CON Finals、强网杯 |
| 混合模式 | 先做题再攻防 | 部分国内赛事 |

### 六大方向（选一个先入门）

| 方向 | 一句话解释 | 比喻 | 入门难度 | 推荐起点 |
|------|-----------|------|---------|---------|
| Web | 找网站的漏洞 | 当"安全质检员"检查一栋楼 | ★★ | DVWA |
| Crypto | 破解密码 | 当"密码破译员" | ★★★ | 古典密码 |
| Pwn | 攻破程序 | 当"开锁匠"撬开程序的锁 | ★★★★ | 栈溢出 |
| Reverse | 反编译程序 | 当"拆解员"逆向拆解玩具看原理 | ★★★★ | 简单 CrackMe |
| Forensics | 数字取证 | 当"侦探"从现场找线索 | ★★★ | 流量分析 |
| Misc | 杂项 | "什么都可能考"的百宝箱 | ★★ | 隐写术 |

> 💡 **小白建议：** 先从 **Web** 或 **Misc** 入手——它们门槛最低，而且学的东西很实用。Pwn 和 Reverse 需要编程和汇编基础，可以后面再学。

---

## 一、Web 方向

### 这类题在考什么？

> Web 题就是给你一个网站（靶站），让你找它的漏洞，然后利用漏洞拿到藏在服务器上的 flag。
>
> 好比你是安全质检员，检查一栋楼（网站）哪里有安全隐患——窗户没锁（SQL注入）、门禁被绕过（越权）、监控有死角（逻辑漏洞）……

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| SQL 注入 | 从注入点获取 flag | union / 盲注 / 堆叠 / 宽字节 |
| XSS | 窃取 Cookie/flag | 存储型 / DOM型 / CSP bypass |
| 文件上传 | 上传 WebShell 获取 flag | MIME 绕过 / 双扩展 / 图片马 |
| 文件包含 | LFI/RFI 读取 flag | php://filter / data:// |
| SSRF | 内网访问/读文件 | gopher:// / dict:// / file:// |
| 反序列化 | PHP/Java 反序列化利用链 | __wakeup / __destruct / Fastjson |
| SSTI | 模板注入执行命令 | Jinja2 / Twig / Freemarker |
| 命令注入 | RCE 获取 flag | 分隔符绕过 / 空格绕过 |
| 逻辑漏洞 | 越权/条件竞争 | IDOR / 竞争条件 / 支付逻辑 |
| 旁路认证 | JWT 伪造 / 弱 Session | none算法 / 弱密钥 / 伪造 |

### Web 解题 Checklist

```
□ 看 HTTP 响应头（Server / X-Powered-By / 自定义头）
□ 看 HTML 源码（注释 / 隐藏字段 / JS 文件）
□ 看 robots.txt / .git / .svn / backup文件
□ 识别框架/CMS（WordPress? ThinkPHP? Flask?）
□ 用 Burp Suite 拦截所有请求，分析参数
□ 尝试目录扫描（dirsearch / gobuster）
□ 每个输入点都测试注入（SQLi / XSS / 命令注入 / 模板注入）
□ 检查 Cookie / Session / JWT 结构
□ 检查文件上传功能
□ 检查是否有 API 接口
```

### Web 常用工具

| 工具 | 用途 | 使用提示 |
|------|------|---------|
| Burp Suite | Web 渗透核心 | 拦截/Repeater/Intruder 必会 |
| dirsearch / gobuster | 目录扫描 | 注意字典选择和速率 |
| sqlmap | SQL 注入自动化 | `--batch --dbs --dump` |
| wpscan | WordPress 扫描 | 枚举用户/插件/主题 |
| WhatWeb | 指纹识别 | `whatweb -a 3 <url>` |
| Nikto | Web 漏洞扫描 | 基础扫描 |
| Postman / curl | 手工请求 | 配合 Burp 使用 |
| CyberChef | 编码解码 | 在线万能工具 |

### Web 解题思路模板

```
1. 信息收集
   → 这是什么站？什么框架？什么语言？
   → 有哪些功能？哪些输入点？
   → 有没有源码泄露？

2. 漏洞定位
   → 哪个输入点可能有问题？
   → 尝试基础 payload（' " < > ; | 等）
   → 观察报错信息

3. 漏洞利用
   → 根据漏洞类型选择利用方式
   → 目标：读取 flag 文件或执行命令获取 flag

4. 绕过限制
   → 有 WAF？尝试编码/分块/大小写
   → 有过滤？分析过滤了什么，寻找绕过
   → 关键：理解过滤逻辑才能绕过
```

---

## 二、Crypto 方向

### 这类题在考什么？

> Crypto 题就是给你一段加密后的数据，让你想办法还原出原始内容（flag）。
>
> 好比你是二战时期的密码破译员——截获了敌方电报，要用数学和逻辑推理把密文还原成明文。
>
> 有时候是"古典密码"（凯撒密码、栅栏密码——就像小学生玩的暗号游戏），有时候是"现代密码"（RSA、AES——需要数学功底）。

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| 古典密码 | 凯撒/维吉尼亚/栅栏/替换 | 频率分析 / 已知明文 |
| 编码混淆 | Base系列/Hex/URL编码 | 多层嵌套编码 |
| RSA | 参数漏洞利用 | 小指数 / 共模 / 低解密指数 / Wiener |
| AES | 模式攻击 | ECB重放 / CBC字节翻转 / Padding Oracle |
| 哈希 | 碰撞/长度扩展 | MD5碰撞 / Hash Length Extension |
| 随机数 | 伪随机数预测 | 种子可预测 / LCG / MT19937 |
| 椭圆曲线 | ECC 相关 | 离散对数 / 异常曲线 |
| Lattice | 格密码 | LLL / CVP / SVP |

### Crypto 解题 Checklist

```
□ 识别密码类型（古典？现代？编码？）
□ 收集所有已知参数（明文/密文/密钥/参数）
□ 检查参数是否有特殊性质（小素数？共享素数？低指数？）
□ 尝试在线工具（dcode.fr / CyberChef / factordb.com）
□ 需要写脚本时用 Python（pycryptodome / gmpy2 / sympy）
```

### Crypto 常用工具

| 工具 | 用途 |
|------|------|
| CyberChef | 编码/解码/加密一站式 |
| dcode.fr | 古典密码识别与破解 |
| factordb.com | 大数分解数据库 |
| RsaCtfTool | RSA 漏洞利用自动化 |
| SageMath | 高级数学计算（格/椭圆曲线） |
| Python pycryptodome | 密码学库 |
| Python gmpy2 | 大数运算 |

### RSA 常见攻击速查

| 漏洞类型 | 条件 | 攻击方法 |
|---------|------|---------|
| 小公钥指数 | e=3, 明文短 | 直接开立方 |
| 共模攻击 | 同一明文，两个不同 e | 扩展欧几里得 |
| Wiener 攻击 | d < N^0.25 | 连分数展开 |
| Fermat 分解 | p,q 相近 | Fermat 因数分解 |
| 已知 phi | 有欧拉函数 | 直接求 d |
| 低解密指数 | d 较小 | Wiener / Boneh-Durfee |

---

## 三、Pwn 方向

### 这类题在考什么？

> Pwn 题给你一个程序（通常是 C/C++ 写的），让你想办法"攻破"它——通过发送特殊输入，让程序执行非预期的操作，最终拿到服务器上的 flag。
>
> 好比你是一个开锁匠——面前有一把锁（程序），你要研究它的结构（反编译），找到设计缺陷（内存漏洞），然后制作一把特殊钥匙（exploit）来打开它。
>
> Pwn 是 CTF 中难度最高的方向之一，需要懂汇编语言、内存结构和编程。但入门可以从最简单的"栈溢出"开始。

> 💡 **小白提示：** "Pwn"这个词来源于游戏术语，意思是"打爆/完虐"。在 CTF 里就是"攻破程序"的意思。

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| 栈溢出 | 覆盖返回地址控制执行 | ret2text / ret2shellcode / ret2libc |
| 格式化字符串 | 任意读写 | %n / %x / 自定义偏移 |
| 堆利用 | 堆管理器漏洞 | Use-After-Free / Double Free / Fastbin Attack |
| 整数溢出 | 整数运算导致逻辑错误 | 有符号/无符号混淆 / 溢出绕过 |
| ROP | 构造 ROP 链 | ret2csu / one_gadget / Bypass NX |
| 保护机制绕过 | 绕过 ASLR/Canary/NX/PIE | 信息泄露 / Brute Force |

### Pwn 解题 Checklist

```
□ 查看保护机制：checksec filename
  - RELRO（GOT 是否可写）
  - Stack Canary（栈溢出检测）
  - NX（栈不可执行）
  - PIE（地址随机化）
□ 分析程序功能：IDA/Ghidra 反编译
□ 找漏洞点：哪里有溢出？哪里有格式化字符串？
□ 确定利用方式：ret2text? ret2libc? shellcode?
□ 确定偏移量：cyclic/pattern 计算溢出偏移
□ 构造 payload 并调试
□ 本地测试通过后远程提交
```

### Pwn 常用工具

| 工具 | 用途 |
|------|------|
| pwntools | Python 编写 exploit 框架（必学） |
| GDB + pwndbg/gef | 动态调试 |
| IDA Pro / Ghidra | 静态反编译 |
| checksec (pwntools) | 查看保护机制 |
| ROPgadget / ropper | 查找 ROP gadget |
| one_gadget | 查找 one-shot RCE gadget |
| libc-database | 通过泄露的 libc 函数地址确定 libc 版本 |

### Pwn 入门路径

```
1. 基础知识：x86/x64 汇编、栈帧结构、调用约定
2. ret2text：最简单的栈溢出，覆盖返回地址到程序自带的后门函数
3. ret2shellcode：注入 shellcode 到栈上，跳转执行（需 NX 关闭）
4. ret2libc：NX 开启时，调用 libc 中的 system("/bin/sh")
5. 格式化字符串：利用 printf("%n") 任意地址写
6. 堆利用：UAF / Fastbin Attack / Unsorted Bin Leak
7. 高级 ROP：ret2csu / SROP / JOP
```

---

## 四、Reverse 方向

### 这类题在考什么？

> Reverse（逆向）题给你一个编译好的程序（看不到源代码），你要把它"拆开"研究它内部逻辑，找到验证逻辑，算出正确的 flag。
>
> 好比你拿到一个组装好的玩具，看不到说明书——你要把它拆开（反编译），研究每个零件怎么工作（分析逻辑），搞清楚"输入什么才能让它显示正确"。
>
> 和 Pwn 的区别：Pwn 是"攻破程序让它执行我的命令"，Reverse 是"理解程序找到正确答案"。Reverse 不需要执行攻击，只需要"读懂"程序。

> 💡 **小白提示：** "逆向工程"听起来很高大上，其实就是"拆东西看原理"。就像有人能把手机拆了研究每个芯片干嘛的，逆向就是把程序拆了研究每段代码干嘛的。

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| 简单 CrackMe | 输入正确 flag | 字符串比较 / XOR / 简单加密 |
| 算法逆向 | 还原加密算法 | 自定义加密 / TEA / RC4 |
| 反调试 | 程序检测调试器 | IsDebuggerPresent / ptrace / 时间检测 |
| 代码混淆 | 程序被混淆 | 花指令 / VM保护 / ollvm |
| 脱壳 | 加壳程序 | UPX / VMP / 自定义壳 |
| Android 逆向 | APK 分析 | jadx / smali / frida |

### Reverse 解题 Checklist

```
□ 文件类型：file filename / 查看PE/ELF
□ 是否加壳：UPX / VMP 检测
□ 字符串分析：strings filename | grep -i flag
□ 反编译/反汇编：IDA / Ghidra 打开
□ 定位关键函数：main / check / verify / encrypt
□ 分析算法逻辑：画出流程图
□ 动态调试：GDB / x64dbg / strace / ltrace
□ 编写求解脚本：根据算法反推 flag
```

### Reverse 常用工具

| 工具 | 用途 | 平台 |
|------|------|------|
| IDA Pro | 反汇编/反编译标杆 | 全平台 |
| Ghidra | 开源反编译 | 全平台 |
| x64dbg | Windows 动态调试 | Windows |
| GDB + pwndbg | Linux 动态调试 | Linux |
| jadx | Android APK 反编译 | 全平台 |
| UPX | 脱 UPX 壳 | 全平台 |
| strace / ltrace | 系统调用/库调用追踪 | Linux |
| angr | 符号执行框架 | Python |

---

## 五、Forensics 方向

### 这类题在考什么？

> Forensics（取证）题给你一个"案发现场"——可能是一段网络流量记录、一个内存快照、一个磁盘镜像、一堆日志文件。你要像侦探一样从中找出线索，拼出 flag。
>
> 好比你是刑侦人员——现场有一堆监控录像（流量包）、被害人手机（内存镜像）、作案工具（可疑文件），你要分析这些证据找出真相。
>
> 这类题最考验耐心和细心——线索可能藏在某个不起眼的包里、某条日志的角落里。

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| 流量分析 | PCAP 文件分析 | Wireshark / tshark / HTTP / TCP流 |
| 内存取证 | 内存镜像分析 | Volatility / 内存中的进程/凭证 |
| 磁盘取证 | 磁盘镜像分析 | FTK Imager / Autopsy / 文件恢复 |
| 日志分析 | Web/系统日志 | 日志中的攻击痕迹 |
| 文件恢复 | 被删除的文件 | 文件雕刻 / 磁盘未分配空间 |
| 隐写提取 | 数据隐藏 | 文件尾部 / 交替数据流 |

### Forensics 解题 Checklist

```
□ 确定文件类型：file / binwalk / xxd
□ 检查文件结构：是否有隐藏数据/附加数据
□ 流量分析：Wireshark 打开，看协议分布
  → HTTP 流？提取文件/凭据
  → DNS 查询？可能藏数据
  → TCP 流？追踪数据流
□ 内存分析：Volatility 插件
  → pslist / pstree（进程）
  → filescan（文件）
  → hashdump（密码哈希）
  → cmdscan（命令历史）
□ 日志分析：提取关键事件
  → 登录失败/成功
  → Web 攻击特征
  → 异常时间点的操作
```

### Forensics 常用工具

| 工具 | 用途 |
|------|------|
| Wireshark / tshark | 网络流量分析 |
| Volatility | 内存取证框架 |
| Autopsy | 磁盘取证 |
| FTK Imager | 磁盘镜像查看 |
| binwalk | 固件/文件分析 |
| foremost / scalpel | 文件雕刻恢复 |
| ExifTool | 元数据查看 |
| 010 Editor | 十六进制编辑 |

---

## 六、Misc 方向

### 这类题在考什么？

> Misc（杂项）是 CTF 里的"百宝箱"——什么都可能考。隐写术（把秘密藏在图片/音频里）、编码解码、脑洞题、社会工程……
>
> 好比"综合知识竞赛"——你不知道下一题会考什么，需要知识面广、思维灵活。
>
> Misc 是最适合小白入门的方向——不需要深厚的编程或数学基础，很多题靠观察、搜索和"灵光一现"就能解。

### 常见考察点

| 类型 | 经典考法 | 关键词 |
|------|---------|--------|
| 隐写术 | 图片/音频/文档藏数据 | LSB / 文件尾 / EXIF / 频谱 |
| 编码解码 | 多层编码 | Base家族 / Hex / URL / 摩尔斯 |
| 流量隐写 | 协议层藏数据 | ICMP payload / DNS隧道 |
| 压缩包 | 伪加密/密码/注释 | ZIP伪加密 / 暴力破解 |
| 社会工程 | OSINT | 搜索引擎 / 社交媒体 |
| 编程题 | 算法/脚本 | 正则 / 数据处理 |
| 脑洞题 | 发散思维 | 非常规思路 |

### Misc 图片隐写 Checklist

```
□ file 查看真实文件类型
□ xxd/binwalk 查看文件头尾是否有附加数据
□ ExifTool 查看元数据
□ stegsolve 查看各颜色通道/LSB
□ zsteg（PNG/BMP 的 LSB 检测）
□ steghide（JPEG 隐写提取，可能需要密码）
□ 检查宽高是否被修改（CRC 校验）
□ 检查是否有多个文件拼接（binwalk -e 提取）
```

### Misc 常用工具

| 工具 | 用途 |
|------|------|
| binwalk | 文件分析/提取 |
| stegsolve | 图片隐写分析 |
| zsteg | PNG/BMP LSB 检测 |
| steghide | JPEG 隐写 |
| ExifTool | 元数据 |
| 010 Editor | 十六进制编辑 |
| Audacity | 音频分析（频谱图） |
| CyberChef | 编码解码 |
| fcrackzip | ZIP 密码破解 |
| QR 研究社 / zbar | 二维码识别 |

---

## CTF 通用技巧

### 小白入门心法

```
拿到题不要急——先观察，再动手。

1. 这是什么类型的题？（Web? Crypto? Misc?）
2. 给了我什么？（文件? 网站? 加密数据?）
3. 正常行为是什么？（网站正常功能长啥样？程序正常运行什么效果？）
4. 哪里可能有"不正常"的地方？（异常的输入框?奇怪的文件头?）

记住：CTF 题目的 flag 一定藏在你"找到漏洞并利用"之后才会出现的地方。
```

### 信息收集习惯

```
每次拿到题目（不管什么方向），先做这几件事：

文件类题目：
1. file 文件名 —— 这是什么类型的文件？（不是看扩展名，看真实类型）
2. binwalk 文件名 —— 里面有没有藏别的文件？
3. strings 文件名 | grep -i flag —— 里面有没有 flag 字样？（运气好直接出）

网站类题目：
1. 看网页源代码（Ctrl+U）—— 注释里可能有线索
2. 看 robots.txt —— 可能暴露隐藏路径
3. 用 Burp Suite 看请求和响应 —— HTTP 头里可能有提示
4. 扫目录（dirsearch / gobuster）—— 可能有隐藏页面
```

### 常见 flag 格式

```
flag{...}
FLAG{...}
ctf{...}
CTF{...}
{...}
# 具体格式看比赛说明
```

### 搜索技巧

```
# Google 搜索
"题目关键词" site:ctftime.org     # 查找类似题目
"题目关键词" writeup               # 查找 writeup
"报错信息"                          # 查找报错解决方案

# GitHub 搜索
题目中的特殊字符串                   # 可能是出题人留的线索

# 在线工具
CyberChef —— 编码解码万能工具
dcode.fr —— 密码学万能工具
factordb.com —— 大数分解
```

### 团队分工建议

| 角色 | 负责方向 | 核心能力 |
|------|---------|---------|
| Web 手 | Web 方向 | Burp / 漏洞利用 / 框架熟悉 |
| Pwn 手 | Pwn 方向 | 汇编 / 栈溢出 / 堆利用 |
| Crypto 手 | Crypto 方向 | 数论 / 密码学 / Python |
| 逆向手 | Reverse 方向 | IDA / 反编译 / 算法还原 |
| 取证手 | Forensics + Misc | 流量分析 / 隐写 / 工具熟练 |

> CTF 是团队赛，每人精通 1-2 个方向，遇到跨方向题目协作解决。
