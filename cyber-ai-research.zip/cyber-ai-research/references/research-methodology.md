# 研究方法论与论文索引

> 本文件是 AI×安全交叉研究的"工具箱"——研究怎么做、论文怎么读、数据集在哪找、实验怎么设计、论文怎么写。
>
> 面向对象：刚开始做 AI 安全方向研究的学生（本科毕设到研一水平）。

---

## 一、研究方法论框架

### 1.1 交叉研究的三种模式

| 模式 | 核心思路 | 举例 | 适合谁 |
|------|---------|------|--------|
| AI → Security | 用 AI 技术解决安全问题 | 用 ML 检测恶意软件 | 安全背景为主 |
| Security → AI | 用安全视角分析 AI 系统 | 研究对抗样本攻击 | AI 背景为主 |
| 双向交叉 | 安全和 AI 互相启发 | 用对抗训练提升模型鲁棒性 | 两者都有基础 |

> 💡 **选题建议：** 如果你安全强 AI 弱，选"AI → Security"（用现成 ML 工具解决安全问题）；如果你 AI 强安全弱，选"Security → AI"（用 ML 知识分析模型弱点）。不要一上来就做双向交叉——容易两头不讨好。

### 1.2 研究选题评估清单

选一个研究方向前，问自己这 6 个问题：

```
□ 问题重要吗？（解决了有什么实际价值？）
□ 前人做过吗？（相关工作综述看了没？）
□ 有数据可用吗？（没有数据怎么做实验？）
□ 有评估方法吗？（怎么证明你的方法有效？）
□ 可复现吗？（别人能重复你的实验吗？）
□ 你能做吗？（技术能力/算力/时间够不够？）
```

### 1.3 研究流程

```
  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
  │ 1. 选方向  │──→│ 2. 读论文  │──→│ 3. 定问题  │──→│ 4. 想方法  │
  └──────────┘    └──────────┘    └──────────┘    └──────────┘
                                                        │
  ┌──────────┐    ┌──────────┐    ┌──────────┐         │
  │ 8. 写论文  │←──│ 7. 分析   │←──│ 6. 跑实验  │←──│ 5. 选数据  │
  └──────────┘    └──────────┘    └──────────┘    └──────────┘
```

---

## 二、经典论文索引

### 2.1 对抗样本方向

#### 开创性论文

| 论文 | 作者 | 年份 | 核心贡献 | 一句话总结 |
|------|------|------|---------|-----------|
| Intriguing properties of neural networks | Szegedy et al. | 2014 | 首次发现深度网络的对抗脆弱性 | DNN 有"盲点"——小扰动就能骗过 |
| Explaining and Harnessing Adversarial Examples | Goodfellow et al. | 2015 | 提出 FGSM 攻击 + 线性假说 | 对抗样本源于模型的线性特性 |
| Towards Deep Learning Models Resistant to Adversarial Attacks | Madry et al. | 2018 | PGD 攻击 + 对抗训练理论 | 对抗训练是"最靠谱"的防御 |
| Towards Evaluating the Robustness of Neural Networks | Carlini & Wagner | 2017 | C&W 攻击（破了大半防御） | 证明很多"防御"其实没用 |
| Adversarial Examples Are Not Bugs, They Are Features | Ilyas et al. | 2019 | 非鲁棒特征假说 | 对抗样本不是 bug，是模型学到了人类看不到的"特征" |

#### 综述论文

| 论文 | 年份 | 推荐理由 |
|------|------|---------|
| Adversarial Attacks and Defences: A Survey | 2018 | 入门综述，系统梳理攻防 |
| Threat of Adversarial Attacks on Deep Learning | 2020 | 全面综述，含评估指标讨论 |
| Adversarial Robustness: From Self-Supervised Pre-Training to Fine-Tuning | 2022 | 结合自监督学习的鲁棒性 |

### 2.2 后门/投毒方向

| 论文 | 作者 | 年份 | 核心贡献 |
|------|------|------|---------|
| BadNets: Identifying Vulnerabilities in the Machine Learning Model Supply Chain | Gu et al. | 2017 | 首次提出后门攻击 |
| Trojaning Attack on Neural Networks | Liu et al. | 2018 | 优化触发器注入 |
| Neural Cleanse: Identifying and Mitigating Backdoor Attacks | Wang et al. | 2019 | 后门检测经典方法 |
| A Benchmark for Backdoor Attack | Wu et al. | 2022 | 后门攻击基准测试 |

### 2.3 模型窃取/隐私方向

| 论文 | 作者 | 年份 | 核心贡献 |
|------|------|------|---------|
| Membership Inference Attacks Against Machine Learning Models | Shokri et al. | 2017 | 成员推断攻击开创性工作 |
| Stealing Neural Networks via Timing Side Channels | Duddu et al. | 2018 | 侧信道模型窃取 |
| Deep Leakage from Gradients | Zhu et al. | 2019 | 联邦学习梯度泄露 |
| Extracting Training Data from Large Language Models | Carlini et al. | 2021 | LLM 训练数据提取 |

### 2.4 AI 赋能安全方向

| 论文 | 作者 | 年份 | 核心贡献 |
|------|------|------|---------|
| EMBER: An Open Dataset for Training Static PE Malware Machine Learning Models | Anderson et al. | 2018 | 恶意软件检测基准数据集 |
| DeepLog: Anomaly Detection and Diagnosis from System Logs | Du et al. | 2017 | LSTM 日志异常检测 |
| A Survey of Machine Learning Techniques for Intrusion Detection | 2020 | 入侵检测 ML 综述 |
| AI-Driven fuzzing: Advancing the state of the art | 2022 | AI Fuzzing 综述 |

### 2.5 LLM 安全方向

| 论文 | 作者 | 年份 | 核心贡献 |
|------|------|------|---------|
| Universal and Transferable Adversarial Attacks on Aligned Language Models | Zou et al. | 2023 | LLM 通用越狱后缀 |
| Not what you've signed up for: Compromising Real-World LLM-Integrated Apps | Greshake et al. | 2023 | 间接 Prompt Injection |
| Extracting Training Data from Large Language Models | Carlini et al. | 2021 | LLM 训练数据提取 |
| Ignore Previous Prompt: Attack Techniques For Language Models | Pinto | 2023 | Prompt Injection 系统分析 |
| Red Teaming Language Models to Reduce Harms | Anthropic | 2022 | LLM 红队方法论 |

### 2.6 综合性综述（入门必读）

| 综述 | 年份 | 覆盖范围 | 推荐度 |
|------|------|---------|--------|
| A Complete Survey on Generative AI for Security | 2024 | AI 赋能安全全景 | ★★★★★ |
| Artificial Intelligence in Cybersecurity: A Comprehensive Survey | 2023 | AI 安全综述 | ★★★★ |
| Security and Privacy of Artificial Intelligence | 2023 | AI 安全与隐私 | ★★★★ |
| Adversarial Machine Learning: A Taxonomy and Survey | 2023 | 对抗 ML 分类 | ★★★★ |
| A Survey on Large Language Model Security | 2024 | LLM 安全综述 | ★★★★★ |

---

## 三、数据集资源索引

### 3.1 AI 赋能安全数据集

| 数据集 | 任务 | 规模 | 获取方式 | 说明 |
|--------|------|------|---------|------|
| EMBER | 恶意软件分类 | 100万+ PE 文件 | GitHub 开源 | 静态特征向量，入门首选 |
| CICIDS2017 | 入侵检测 | 2.8M 流 | 官网下载 | 现代攻击类型，有标签噪声 |
| CSE-CIC-IDS2018 | 入侵检测 | 16M 流 | AWS 开放 | IDS2017 升级版 |
| UNSW-NB15 | 入侵检测 | 2.5M 记录 | 官网下载 | 49 种特征 |
| TON_IoT | IoT 入侵检测 | 多源遥测 | Kaggle | IoT 场景 |
| BigVul | 代码漏洞检测 | 10K+ 函数 | GitHub | C/C++ 代码漏洞 |
| Devign | 代码漏洞检测 | 27K 函数 | GitHub | 图神经网络基准 |
| Phishing Corpus | 钓鱼邮件检测 | 数千封 | 公开 | 经典邮件数据 |
| CICAndMal2017 | Android 恶意软件 | 20K+ 样本 | 官网 | 静态+动态特征 |
| MalMem | 内存取证 | — | 官网 | 内存恶意软件检测 |

> ⚠️ **数据集避坑：**
> - KDD Cup 99 / NSL-KDD 太老了，别用发论文（审稿人会拒）
> - CICIDS2017 有标签噪声，用之前要清洗
> - 不要只用一个数据集——多数据集交叉验证更有说服力

### 3.2 安全赋能 AI 数据集

| 数据集 | 任务 | 说明 |
|--------|------|------|
| MNIST / CIFAR-10 / ImageNet | 对抗攻击实验 | 标准 ML 基准数据集 |
| TrojAI | 后门检测竞赛 | NIST 举办的后门检测挑战 |
| ImageNet-P / ImageNet-C | 鲁棒性评估 | 扰动/损坏下的模型表现 |
| AdvBench | LLM 越狱测试 | 有害行为提示词集合 |
| HarmBench | LLM 安全评估 | 标准化 LLM 安全基准 |
| RealToxicityPrompts | LLM 毒性评估 | 检测 LLM 生成有害内容 |

### 3.3 数据集搜索平台

| 平台 | 网址 | 说明 |
|------|------|------|
| Kaggle Datasets | kaggle.com/datasets | 通用数据集平台 |
| HuggingFace Datasets | huggingface.co/datasets | NLP/LLM 数据集 |
| PapersWithCode | paperswithcode.com/datasets | 论文+数据集+代码 |
| Google Dataset Search | datasetsearch.research.google.com | 数据集搜索引擎 |
| UCI ML Repository | archive.ics.uci.edu | 经典 ML 数据集 |
| CIC Datasets | unsig.ca/datasets | 安全专用数据集 |

---

## 四、实验设计框架

### 4.1 AI 赋能安全实验模板

```
实验设计：用 [AI 方法] 解决 [安全问题]

1. 问题定义
   - 要检测/分析什么安全威胁？
   - 现有方法有什么不足？

2. 数据准备
   - 数据集：[选择数据集]
   - 数据预处理：[清洗/特征提取/划分方式]
   - 数据划分：训练集 / 验证集 / 测试集 = X:Y:Z

3. 基线模型
   - 传统方法：[规则/签名/经典ML] 作为对比基准
   - 已有AI方法：[现有论文的方法] 作为对比

4. 你的方法
   - 核心创新：[你的方法比基线好在哪？]
   - 技术路线：[数据 → 特征 → 模型 → 输出]

5. 评估指标
   - 分类：准确率 / 精确率 / 召回率 / F1 / ROC-AUC
   - 检测：检测率 / 误报率（FPR）/ ROC 曲线
   - 效率：推理时间 / 内存占用
   - 鲁棒性：对抗攻击下的表现

6. 消融实验
   - 去掉你的创新点 A → 效果降多少？
   - 去掉你的创新点 B → 效果降多少？
   - 证明每个创新点都有贡献

7. 可解释性
   - SHAP / LIME 解释模型决策
   - 特征重要性分析
```

### 4.2 安全赋能 AI 实验模板

```
实验设计：[攻击/防御] [AI 系统的某个弱点]

1. 威胁模型
   - 攻击者能力：白盒/黑盒/灰盒
   - 攻击者目标：可用性/完整性/机密性/隐私
   - 攻击者知识：知道模型什么信息？

2. 实验设置
   - 目标模型：[选什么模型]
   - 数据集：[选什么数据]
   - 攻击方法：[用什么攻击]
   - 防御方法（如果有）：[用什么防御]

3. 评估指标
   - 攻击：攻击成功率（ASR）/ 扰动大小（Lp范数）/ 查询次数
   - 防御：鲁棒准确率（Robust Accuracy）/ 精度损失
   - 效率：攻击/防御的计算开销

4. 对比实验
   - 和已有攻击/防御方法对比
   - 在不同模型/数据集上验证泛化性

5. 讨论
   - 为什么你的方法有效？
   - 有什么局限性？
   - 对手可能的对策？
```

### 4.3 实验管理最佳实践

| 实践 | 说明 | 工具推荐 |
|------|------|---------|
| 实验记录 | 记录每次实验的参数和结果 | MLflow / Weights & Biases / TensorBoard |
| 代码版本 | 代码+参数+结果绑定 | Git + DVC |
| 随机性控制 | 固定随机种子 | torch.manual_seed / np.random.seed |
| 统计显著性 | 多次运行取均值±标准差 | 至少跑 3-5 次取平均 |
| 复现性 | 提供完整配置文件 | Hydra / YAML 配置 |

---

## 五、论文写作指南

### 5.1 AI 安全论文结构

```
1. Abstract（摘要）
   - 一段话讲清楚：问题 + 方法 + 结果 + 贡献

2. Introduction（引言）
   - 背景：为什么这个问题重要
   - 挑战：现有方法的不足
   - 你的方法：你做了什么
   - 贡献：分点列出（通常 3-4 点）

3. Related Work（相关工作）
   - 按主题分组讨论前人工作
   - 最后说明你的工作和它们的区别

4. Background / Preliminaries（背景知识）
   - 必要的技术背景（让审稿人能看懂你的方法）

5. Methodology / Approach（方法）
   - 你的核心方法——这是论文最重要的部分
   - 问题定义 → 方法概述 → 技术细节 → 算法伪代码

6. Experiments（实验）
   - 实验设置（数据集/模型/参数）
   - 主实验结果（和基线对比）
   - 消融实验
   - 分析实验

7. Discussion（讨论）
   - 为什么有效 / 局限性 / 未来工作

8. Conclusion（结论）
   - 总结贡献
```

### 5.2 AI 安全论文的常见审稿意见

| 审稿意见 | 怎么避免 |
|---------|---------|
| "数据集太老" | 别用 KDD99，用 CICIDS2017+ |
| "只有一个数据集" | 至少 2-3 个数据集交叉验证 |
| "没有和最新方法对比" | 相关工作要查到最近 2 年 |
| "可复现性差" | 提供代码/配置/随机种子 |
| "只做攻击没做防御"（Security→AI） | 加防御讨论或防御实验 |
| "没有讨论局限性" | 诚实写 Discussion 段 |
| "创新点不明确" | Introduction 最后明确列贡献点 |

### 5.3 投稿方向参考

| 方向 | 适合的会议/期刊 | 等级 | 说明 |
|------|----------------|------|------|
| AI 安全顶会 | USENIX Security / S&P / CCS / NDSS | CCF-A | 安全顶会，偏系统安全 |
| AI 安全顶会 | NeurIPS / ICML / ICLR | CCF-A | AI 顶会，偏算法理论 |
| AI 安全期刊 | TIFS / TDSC | SCI-Q1 | 期刊，周期长 |
| AI 应用安全 | ACSAC / ESORICS / RAID | CCF-B | 应用安全 |
| LLM 安全 | ACL / EMNLP / NAACL | CCF-B/A | NLP 顶会有 LLM 安全赛道 |

---

## 六、工具与环境

### 6.1 AI 安全研究工具箱

| 类别 | 工具 | 说明 |
|------|------|------|
| 对抗攻击 | Foolbox / ART / CleverHans | 对抗样本生成与评估 |
| 后门研究 | BackdoorBox / TrojanZoo | 后门攻击与检测 |
| LLM 安全 | Garak / PyRIT / Promptfoo | LLM 安全评估 |
| 模型隐私 | ML Privacy Meter | 成员推断评估 |
| 可解释性 | SHAP / LIME / Captum | 模型决策解释 |
| 实验管理 | MLflow / W&B | 实验跟踪与可视化 |
| 深度学习 | PyTorch / TensorFlow | 模型训练 |
| 传统 ML | scikit-learn / XGBoost | 表格数据基线 |

### 6.2 推荐开发环境

```python
# 通用 AI 安全实验环境
# Python 3.10+ / PyTorch 2.0+

# 核心库
pip install torch torchvision torchaudio
pip install scikit-learn xgboost
pip install foolbox adversarial-robustness-toolbox
pip install shap lime
pip install matplotlib seaborn

# LLM 安全
pip install garak
pip install transformers accelerate

# 实验管理
pip install wandb mlflow
```

### 6.3 算力需求参考

| 实验类型 | 最低算力 | 推荐 |
|---------|---------|------|
| 表格数据 ML（恶意软件分类） | CPU 可跑 | 16GB RAM |
| 小型 CNN 对抗攻击（MNIST/CIFAR） | 单 GPU（4GB+） | RTX 3060+ |
| 大模型对抗攻击（ImageNet） | 多 GPU | A100 / V100 |
| LLM 安全实验（7B 模型） | 16GB+ 显存 | A100 / 多卡 |
| 对抗训练 | 大量 GPU 时间 | 多 A100 |

> 💡 **没有 GPU 怎么办？**
> - Google Colab（免费 T4 GPU，够跑小实验）
> - Kaggle Notebooks（免费 P100）
> - 学校超算中心
> - AutoDL / 腾讯云等按量租用

---

## 七、研究路线图

### 7.1 入门路线（0-3 个月）

```
第 1 个月：打基础
  Week 1-2: 学对抗样本基础（读 Goodfellow 2015 + Madry 2018）
  Week 3-4: 跑通 FGSM 攻击 MNIST 的实验（用 Foolbox）

第 2 个月：读论文 + 复现
  Week 5-6: 读 5-10 篇经典论文（按本文件索引）
  Week 7-8: 选一篇论文尝试复现

第 3 个月：定方向 + 小实验
  选一个方向深入（AI→Sec 或 Sec→AI）
  做一个完整的小实验（数据→方法→评估→分析）
```

### 7.2 进阶路线（3-12 个月）

```
第 4-6 个月：深入一个子方向
  - 系统读完该方向近 3 年的所有顶会论文
  - 建立自己的论文笔记库
  - 尝试改进现有方法

第 7-9 个月：做实验
  - 设计自己的方法
  - 在多个数据集上验证
  - 做充分的对比和消融实验

第 10-12 个月：写论文
  - 整理实验结果
  - 按论文模板写作
  - 找导师/同学 review
  - 投稿
```

### 7.3 论文笔记模板

```
## 论文：[标题]
- 作者：[第一作者 et al.]
- 发表：[会议/期刊 年份]
- 链接：[arXiv/DOI]

### 一句话总结
> [这篇论文用 X 方法解决了 Y 问题]

### 研究问题
[要回答什么问题？为什么重要？]

### 方法
[核心创新点是什么？技术路线？]

### 实验
- 数据集：
- 基线：
- 指标：
- 核心结果：

### 优点
[方法好在哪？]

### 局限
[有什么不足？]

### 对我的启发
[能不能用到我的研究？有什么可改进的？]
```

---

## 八、社区与资源

### 8.1 学术社区

| 社区 | 类型 | 说明 |
|------|------|------|
| arXiv (cs.CR + cs.LG) | 预印本 | AI 安全最新论文 |
| PapersWithCode | 论文+代码 | 可复现的论文 |
| Google Scholar | 论文搜索 | 设关键词提醒 |
| Connected Papers | 论文关系图 | 发现相关论文 |
| Twitter/X (#AIsecurity) | 学术社交 | 很多研究者在这分享 |

### 8.2 竞赛平台

| 平台 | 竞赛 | 说明 |
|------|------|------|
| Kaggle | 各类安全 ML 竞赛 | 入门竞赛练手 |
| TrojAI (NIST) | 后门检测挑战 | AI 安全专项竞赛 |
| DEF CON AI Village | CTF + AI 安全 | 安全会议 AI 赛道 |
| Alibaba Security | 天池安全算法赛 | 工业界安全竞赛 |

### 8.3 开源项目

| 项目 | 说明 |
|------|------|
| Microsoft Counterfit | AI 红队测试框架 |
| NVIDIA NeMo Guardrails | LLM 安全护栏 |
| IBM ART | 对抗鲁棒性工具箱 |
| HuggingFace SafeML | 模型安全扫描 |
| NIST AI Safety | AI 安全评估工具 |
