# 网络扫描与嗅探工具详解

> 本文件覆盖网络层核心工具：Nmap、Wireshark、Masscan、tcpdump、Aircrack-ng。
> 每个工具按"定位 → 比喻 → 安装 → 核心命令 → 进阶技巧"组织。

---

## 一、Nmap —— 网络扫描的望远镜

### 定位

Nmap（Network Mapper）是网络扫描和主机发现的标准工具，能探测主机在线状态、开放端口、运行服务、操作系统类型等。

### 比喻

> Nmap 就像一个"门卫巡视员"——挨个敲门看哪个房间有人（主机发现）、开着什么门（端口扫描）、门后是什么服务（服务版本）、房间是什么户型（操作系统识别）。它只能"看"不能"打"——发现端口后要用别的工具去利用。

### 安装

- **Kali Linux**：已预装
- **Windows**：下载 [nmap.org](https://nmap.org/download.html)
- **Mac**：`brew install nmap`

### 核心命令

```bash
# 基础扫描：扫常见 1000 个端口
nmap 192.168.56.101

# 扫描所有 65535 个端口
nmap -p- 192.168.56.101

# 服务版本探测
nmap -sV 192.168.56.101

# 操作系统识别
nmap -O 192.168.56.101

# 综合扫描：脚本 + 版本 + OS
nmap -A 192.168.56.101

# 扫描一个网段
nmap 192.168.56.0/24

# 快速扫描（加速）
nmap -T4 -F 192.168.56.101
```

### 核心参数速查

| 参数 | 作用 | 比喻 |
|------|------|------|
| `-sS` | SYN 半开扫描（默认，隐蔽） | 敲门就跑，不等回应 |
| `-sT` | TCP 全连接扫描 | 敲门进去坐下来 |
| `-sV` | 服务版本探测 | 问门后的人"你是谁" |
| `-O` | 操作系统识别 | 看户型判断是什么楼 |
| `-A` | 综合扫描（= -sV + -O + 脚本） | 全面体检 |
| `-p-` | 扫所有 65535 端口 | 每扇门都敲一遍 |
| `-p 80,443` | 指定端口 | 只敲这两扇门 |
| `-T4` | 加速（0-5，越高越快） | 巡视速度调快 |
| `-sn` | 只做主机发现（不扫端口） | 只看有没有人，不敲门 |
| `-oN result.txt` | 输出到文件 | 把巡视记录存下来 |
| `--script=vuln` | 用漏洞扫描脚本 | 带着问题清单检查 |

💡 小白提示：
- `-T4` 是日常推荐速度。`-T5`（疯狂模式）发包太快，可能导致结果不准，甚至把靶场服务扫崩。
- `-A` 扫描比较慢但信息全，第一次接触一个目标时建议用 `-A`。
- 扫描结果中 `open` = 端口开放；`closed` = 端口关闭但可达；`filtered` = 被防火墙挡了，判断不了。

### Nmap 脚本引擎（NSE）

Nmap 自带几百个脚本，在 `/usr/share/nmap/scripts/` 目录下。

```bash
# 漏洞扫描脚本
nmap --script=vuln 192.168.56.101

# SMB 漏洞检测（如永恒之蓝）
nmap --script=smb-vuln* 192.168.56.101

# HTTP 标题抓取
nmap --script=http-title 192.168.56.101

# FTP 匿名登录检测
nmap --script=ftp-anon 192.168.56.101
```

### 进阶技巧

- **规避防火墙**：`-f`（分片发包）、`--mtu 24`（指定 MTU）、`-D RND:5`（5 个 decoy 伪造源 IP）
- **扫描结果对比**：先存基线 `nmap -oN baseline.txt target`，过段时间再扫，diff 两个文件看变化
- **定时扫描**：`nmap -T2 target`（低速模式，更隐蔽但更慢）

---

## 二、Wireshark —— 流量分析的显微镜

### 定位

Wireshark 是网络协议分析的标准工具，能抓取并解析网络数据包，是网络流量分析、故障排查和安全分析的核心工具。

### 比喻

> Wireshark 就像一个"邮政检查员"的放大镜——所有经过的信件（数据包）你都能拆开看，信封上写了什么（源/目的 IP）、信纸写的什么（数据内容）、用什么语言写的（协议），全部看得清清楚楚。

### 安装

- **Kali Linux**：已预装
- **Windows/Mac**：下载 [wireshark.org](https://www.wireshark.org/download.html)

### 界面导览

| 区域 | 说明 |
|------|------|
| **过滤器栏** | 输入过滤条件，只显示匹配的包 |
| **包列表** | 每行一个数据包，显示序号/时间/源/目的/协议/信息 |
| **包详情** | 点选某个包后，按协议层展开看详情 |
| **包数据** | 十六进制+ASCII 的原始数据 |

### 核心过滤器

```
# 只看某个 IP 的流量
ip.addr == 192.168.56.101

# 只看 HTTP 流量
http

# 只看某个端口的流量
tcp.port == 80

# 只看 POST 请求
http.request.method == "POST"

# 只看某个 URL
http.request.uri contains "login"

# 排除某类流量
!arp && !dns

# 追踪 TCP 流（看完整对话）
右键包 → Follow → TCP Stream

# 只看含特定关键词的包
frame contains "password"
```

💡 小白提示：抓包前先写好过滤器，否则抓到的包太多根本看不过来。最常用的操作是"抓包 → 写过滤条件 → 右键 Follow TCP Stream 看完整对话"。

### 核心操作：抓取 HTTP 登录凭证

1. 打开 Wireshark → 选网卡（如 eth0）→ 开始抓包
2. 在靶场里提交一个登录表单
3. 停止抓包
4. 过滤器输入 `http.request.method == "POST"`
5. 找到登录请求 → 展开 HTML Form 表单 → 看 username 和 password 字段

### 进阶技巧

- **统计 → 协议分级**：看各类协议的流量占比，快速判断异常
- **统计 → 会话**：看哪两个 IP 之间通信最多，排查异常连接
- **导出对象**：File → Export Objects → HTTP，导出所有 HTTP 传输的文件（图片/文档等）
- **解密 TLS**：配置 SSLKEYLOGFILE 环境变量可以解密 HTTPS 流量

---

## 三、Masscan —— 互联网级端口扫描器

### 定位

Masscan 是一款异步端口扫描器，号称能在 6 分钟内扫完整个互联网的 80 端口。适合大规模快速端口发现。

### 比喻

> Nmap 是"挨个敲门"的巡视员，Masscan 是"同时派一万个信使"的快递公司——它用异步发包技术实现超高速扫描，但精度不如 Nmap。

### 安装

- **Kali Linux**：已预装
- **其他**：`apt install masscan` 或 `git clone https://github.com/robertdavidgraham/masscan.git`

### 核心命令

```bash
# 扫描某 IP 的指定端口
masscan 192.168.56.101 -p 80,443,8080

# 扫描网段的常见端口
masscan 192.168.56.0/24 -p 1-65535 --rate=1000

# 超高速扫描（注意：可能影响网络）
masscan 10.0.0.0/8 -p 80 --rate=10000
```

### Nmap vs Masscan

| | Nmap | Masscan |
|---|------|---------|
| 速度 | 慢，精确 | 非常快 |
| 精度 | 高 | 中（可能有误报） |
| 功能 | 端口+服务+OS+脚本 | 仅端口 |
| 适用 | 精确扫描单机/小范围 | 大范围快速端口发现 |

**组合用法**：先用 Masscan 快速扫大范围找开放端口 → 再用 Nmap 对发现的端口做精确探测。

💡 小白提示：Masscan 的 `--rate` 参数设太高可能导致网络拥塞或被防火墙封。靶场环境建议 `--rate=1000` 足够。

---

## 四、tcpdump —— 命令行抓包工具

### 定位

tcpdump 是命令行网络抓包工具，没有图形界面，但轻量高效，适合在服务器上使用。

### 比喻

> tcpdump 就像 Wireshark 的"命令行精简版"——没有图形界面，但可以在任何服务器上直接跑，适合没有桌面的远程环境。

### 安装

- **Kali Linux**：已预装
- **大多数 Linux**：`apt install tcpdump`

### 核心命令

```bash
# 抓取所有流量
tcpdump -i eth0

# 抓取指定端口
tcpdump -i eth0 port 80

# 抓取指定 IP
tcpdump -i eth0 host 192.168.56.101

# 抓取并显示 ASCII 内容
tcpdump -i eth0 -A port 80

# 写入文件（用 Wireshark 打开分析）
tcpdump -i eth0 -w capture.pcap

# 组合过滤
tcpdump -i eth0 'tcp port 80 and host 192.168.56.101' -w capture.pcap
```

### 进阶技巧

- **抓密码明文**：`tcpdump -i eth0 -A port 80 | grep -i "pass"`（抓 HTTP 明文密码）
- **导出 pcap 给 Wireshark**：`tcpdump -w file.pcap`，然后用 Wireshark 打开 `.pcap` 文件深度分析
- **读取 pcap 文件**：`tcpdump -r capture.pcap`

---

## 五、Aircrack-ng —— 无线网络安全工具套件

### 定位

Aircrack-ng 是一套无线网络安全评估工具，用于抓包、破解 WEP/WPA/WPA2 密码、分析无线网络。

### 比喻

> Aircrack-ng 就像"撬 WiFi 锁的工具箱"——先监听别人在连 WiFi 时的"握手信号"（四次握手包），然后拿着这些信号离线暴力试密码。

### 核心工具

| 工具 | 作用 |
|------|------|
| `airmon-ng` | 开启网卡监听模式 |
| `airodump-ng` | 扫描附近的 WiFi |
| `aireplay-ng` | 发送注入包（强制断开重连） |
| `aircrack-ng` | 破解抓到的握手包 |

### 基本流程

```bash
# 1. 开启监听模式
airmon-ng start wlan0

# 2. 扫描附近 WiFi
airodump-ng wlan0mon

# 3. 锁定目标抓握手包
airodump-ng -c 6 --bssid AA:BB:CC:DD:EE:FF -w capture wlan0mon

# 4. 强制目标重连（另开终端）
aireplay-ng --deauth 5 -a AA:BB:CC:DD:EE:FF wlan0mon

# 5. 破解握手包
aircrack-ng -w /usr/share/wordlists/rockyou.txt capture-01.cap
```

⚠️ **安全约束：** 以上操作仅限自己拥有或获得明确授权的 WiFi 网络。未经授权破解他人 WiFi 是违法行为。

💡 小白提示：Aircrack-ng 需要支持监听模式的无线网卡。普通笔记本网卡可能不支持，需购买专用 USB 无线网卡（如 Alfa AWUS036ACH）。

---

## 工具组合拳：网络侦察工具链

```
1. Masscan 快速扫端口 → 大范围发现开放端口
2. Nmap 精确扫描 → 对发现的端口做服务版本+OS识别
3. Wireshark 抓包分析 → 分析可疑端口的流量内容
4. tcpdump 服务器抓包 → 在没有桌面的服务器上抓包存 pcap
5. Aircrack-ng → 无线网络专项评估（仅限授权环境）
```
