# Web 安全工具详解

> 本文件覆盖 Web 安全领域核心工具：Burp Suite、OWASP ZAP、sqlmap、Nikto、目录扫描工具族。
> 每个工具按"定位 → 比喻 → 安装 → 界面/命令 → 核心操作 → 进阶技巧"组织。

---

## 一、Burp Suite —— Web 安全的瑞士军刀

### 定位

Burp Suite 是 PortSwigger 公司开发的 Web 安全测试集成平台，是 Web 渗透测试的行业标配。社区版免费，专业版收费。

### 比喻

> Burp 就像快递中转站的"检查台"——所有包裹（HTTP 请求）都得先经过它。你可以拆开看、改内容再放行、或者反复发同一个包裹看系统反应。它是你和网站之间的"中间人"。

### 安装

- **Kali Linux**：已预装，直接在应用菜单搜索 Burp Suite
- **Windows/Mac**：去 [portswigger.net](https://portswigger.net/burp) 下载安装包
- 启动后选择 "Temporary project" → "Use Burp defaults" → "Start Burp"

### 核心模块导览

| 模块 | 比喻 | 干什么 |
|------|------|--------|
| **Proxy**（代理） | 检查台 | 拦截浏览器和服务器之间的所有请求，可以看、可以改、可以放行 |
| **Repeater**（重放器） | 复印机 | 把一个请求复制出来反复修改重发，观察每次的响应 |
| **Intruder**（入侵者） | 自动发件机 | 自动批量发请求，做暴力破解、枚举、Fuzzing |
| **Decoder**（解码器） | 翻译机 | Base64/URL/Hex 等编码格式互转 |
| **Comparer**（对比器） | 找茬游戏 | 对比两个响应的差异 |
| **Scanner**（扫描器） | 体检医生 | 自动扫描漏洞（专业版功能） |

### 核心操作：抓包改包

#### 第 1 步：配置浏览器代理

Burp 默认在 127.0.0.1:8080 监听。

- **方法一**：装 SwitchyOmega 插件，设置代理 127.0.0.1:8080
- **方法二**：浏览器设置 → 代理 → 手动代理 → 127.0.0.1:8080

💡 小白提示：如果配置代理后浏览器访问所有网站都报错，别慌——这是因为 Burp 在拦截但还没装证书。先访问 `http://burp` 下载并安装 CA 证书。

#### 第 2 步：开启拦截

Burp → Proxy → Intercept → 点 "Intercept is on"

#### 第 3 步：浏览器访问靶场

访问 DVWA（如 `http://192.168.56.101/dvwa/`），请求会被 Burp 拦住。

#### 第 4 步：看包改包

- 拦截到的请求会显示在 Burp 中
- 可以直接编辑请求内容（改参数、加头、改 Cookie）
- 点 "Forward" 放行，点 "Drop" 丢弃

#### 第 5 步：发到 Repeater

右键拦截到的请求 → "Send to Repeater" → 切到 Repeater 标签 → 修改请求 → 点 "Send" → 看右侧响应

💡 小白提示：Repeater 是最常用的模块。做 Web 题时，"抓包 → 发到 Repeater → 反复试"是标准流程。

### 进阶技巧

- **Intruder 暴力破解**：把请求发到 Intruder，用 `§` 标记要替换的位置，加载字典批量测试
- **匹配替换规则**：Proxy → Options → Match and Replace，自动替换请求/响应中的内容
- **Burp 插件（BApp Store）**：装 SQLiPy（对接 sqlmap）、Autorize（权限测试）等

---

## 二、OWASP ZAP —— 免费的 Burp 替代品

### 定位

OWASP ZAP（Zed Attack Proxy）是 OWASP 基金会维护的开源 Web 安全测试工具，功能类似 Burp，完全免费。

### 比喻

> ZAP 就像 Burp 的"平替版"——功能差不多，免费开源，适合学生和预算有限的团队。

### 安装

- **Kali Linux**：已预装
- **跨平台**：下载 [zaproxy.org](https://www.zaproxy.org/download/)

### 核心功能

| 功能 | 说明 |
|------|------|
| 代理拦截 | 类似 Burp Proxy |
| 主动扫描 | 自动爬取网站并扫描漏洞 |
| 被动扫描 | 代理流量时自动检测漏洞 |
| Fuzzer | 类似 Burp Intruder |
| API | 提供 REST API 可编程控制 |

### 什么时候选 ZAP 而不是 Burp

- 预算有限（ZAP 完全免费）
- 需要自动化 CI/CD 集成（ZAP 有完善的 API）
- 教学/入门（ZAP 界面更简洁）
- 否则，Burp 仍然是首选（插件生态更好）

---

## 三、sqlmap —— SQL 注入自动化工具

### 定位

sqlmap 是一款开源的 SQL 注入自动化检测与利用工具，输入一个可能存在注入的 URL，它能自动检测注入类型并提取数据库数据。

### 比喻

> sqlmap 就像一把"自动开锁枪"——你告诉它哪扇门可能有锁（可疑 URL），它自己试各种钥匙（注入手法），能开就帮你打开，还能把屋里东西（数据库数据）全搬出来。

### 安装

- **Kali Linux**：已预装
- **其他**：`git clone https://github.com/sqlmapproject/sqlmap.git`

### 核心命令

```bash
# 基础检测：判断是否存在注入
sqlmap -u "http://192.168.56.101/dvwa/vulnerabilities/sqli/?id=1&Submit=Submit" --cookie="PHPSESSID=xxx; security=low"

# 获取数据库列表
sqlmap -u "URL" --cookie="xxx" --dbs

# 获取当前数据库名
sqlmap -u "URL" --cookie="xxx" --current-db

# 获取指定数据库的表
sqlmap -u "URL" --cookie="xxx" -D dvwa --tables

# 获取指定表的列
sqlmap -u "URL" --cookie="xxx" -D dvwa -T users --columns

# 导出指定列的数据
sqlmap -u "URL" --cookie="xxx" -D dvwa -T users -C user,password --dump
```

💡 小白提示：DVWA 的 SQL 注入页面需要登录态，所以必须带 `--cookie`。怎么拿 Cookie？用 Burp 抓包看请求头里的 Cookie。

### 核心参数速查

| 参数 | 作用 | 比喻 |
|------|------|------|
| `-u` | 指定目标 URL | 告诉它哪扇门 |
| `--cookie` | 带 Cookie | 出示通行证 |
| `--dbs` | 列所有数据库 | 看有几栋楼 |
| `-D` | 指定数据库 | 选哪栋楼 |
| `--tables` | 列表 | 看楼里几间房 |
| `-T` | 指定表 | 选哪间房 |
| `--columns` | 列列 | 看房里有几个柜子 |
| `-C` | 指定列 | 选哪个柜子 |
| `--dump` | 导出数据 | 把柜子东西搬出来 |
| `--batch` | 自动选默认（不问 yes/no） | 别问我，用默认 |
| `--level=5` | 检测级别（1-5，越高越全） | 试多少种钥匙 |
| `--risk=3` | 风险级别（1-3，越高越激进） | 钥匙拧多猛 |

### 进阶技巧

- **POST 注入**：用 `--data="param=value"` 指定 POST 参数
- **从 Burp 导入**：`-r request.txt`（把 Burp 抓的完整请求存成文件喂给它）
- **OS Shell**：`--os-shell`（如果能写文件，尝试获取操作系统命令执行）
- **绕过 WAF**：`--tamper="space2comment"`（用绕过脚本把空格替换成注释）

---

## 四、Nikto —— Web 服务器漏洞扫描器

### 定位

Nikto 是一款开源的 Web 服务器漏洞扫描器，检测危险文件、过期软件、配置问题等。

### 比喻

> Nikto 就像一个"安检员"——拿着一份问题清单（已知漏洞和危险配置），挨个检查你的 Web 服务器有没有中招。它查得广但不深，适合快速体检。

### 安装

- **Kali Linux**：已预装
- **其他**：`git clone https://github.com/sullo/nikto.git`

### 核心命令

```bash
# 基础扫描
nikto -h http://192.168.56.101/

# 指定端口
nikto -h 192.168.56.101 -p 80,443,8080

# 输出报告
nikto -h http://192.168.56.101/ -o result.html -Format htm
```

### 特点

- ✅ 扫描速度快，覆盖面广
- ✅ 免费开源
- ❌ 噪音大（容易被 WAF/IDS 发现）
- ❌ 不验证漏洞可利用性（报"可能有"但不一定真能打）

💡 小白提示：Nikto 的扫描结果里很多是"信息收集"类的发现（比如服务器版本、开放的目录），不一定是漏洞。看到结果别慌，逐条分析。

---

## 五、目录扫描工具族 —— Gobuster / DirBuster / Feroxbuster

### 定位

这类工具通过暴力枚举目录和文件名，发现网站上隐藏的页面、后台入口、备份文件等。

### 比喻

> 目录扫描就像"挨个试门把手"——你拿着一本电话簿（字典文件），挨个房间号（目录名）敲门，看哪个门开了。

### 工具对比

| 工具 | 语言 | 速度 | 特点 |
|------|------|------|------|
| **Gobuster** | Go | 快 | Kali 预装，命令行简洁 |
| **DirBuster** | Java | 中 | 有 GUI，自带字典 |
| **Feroxbuster** | Rust | 非常快 | 支持递归扫描，递归发现目录 |
| **dirsearch** | Python | 中 | 简单易用，字典丰富 |

### Gobuster 核心命令

```bash
# 目录扫描
gobuster dir -u http://192.168.56.101/ -w /usr/share/wordlists/dirb/common.txt

# 指定扩展名
gobuster dir -u http://192.168.56.101/ -w wordlist.txt -x php,html,txt

# 子域名扫描
gobuster dns -d example.com -w subdomains.txt
```

### 常用字典

- Kali 自带：`/usr/share/wordlists/dirb/common.txt`、`/usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt`
- SecLists（推荐安装）：`/usr/share/seclists/` 下有海量字典

💡 小白提示：扫描目录时加 `-x php,html,txt` 指定扩展名很重要——很多后台页面是 `admin.php` 不是 `admin/`。

### 进阶技巧

- **Feroxbuster 递归扫描**：`feroxbuster -u http://target/ --depth 3`，发现目录后自动往里扫
- **结合状态码过滤**：`gobuster dir -u URL -w wordlist -s 200,301,302`，只看有意义的响应码
- **大字典 + 多线程**：`gobuster dir -u URL -w big.txt -t 50`，50 线程加速

---

## 工具组合拳：Web 渗透测试工具链

```
1. Nmap 扫端口 → 发现 80 端口开放
2. Nikto 快速体检 → 发现 Web 服务器已知问题
3. Gobuster 扫目录 → 发现 /admin、/backup 等隐藏入口
4. Burp Suite 抓包 → 分析请求参数，找注入点
5. sqlmap 自动注入 → 确认 SQL 注入并提取数据
```

每一步的输出给下一步用：Nmap 发现端口 → Nikto 扫该端口服务 → Gobuster 扫该服务目录 → Burp 分析可疑目录的请求 → sqlmap 打可疑参数。
