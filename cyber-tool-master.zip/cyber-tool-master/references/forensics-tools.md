# 取证与密码破解工具详解

> 本文件覆盖数字取证与密码破解核心工具：Volatility、Autopsy、John the Ripper、Hashcat、Ghidra、IDA、foremost/binwalk。
> 这些工具既用于攻防研究，也用于防御端的应急响应和取证分析。

---

## 一、Volatility —— 内存取证分析框架

### 定位

Volatility 是一款开源内存取证框架，能从内存镜像（RAM dump）中提取进程、网络连接、密码、注册表等信息，是数字取证和应急响应的核心工具。

### 比喻

> Volatility 就像一个"记忆考古学家"——服务器内存就像一片考古遗址，里面有运行过的程序、连过的网络、输过的密码的痕迹。Volatility 把这些痕迹一层层挖出来。

### 安装

- **Volatility 2（Python2）**：`git clone https://github.com/volatilityfoundation/volatility.git`
- **Volatility 3（Python3，推荐）**：`pip3 install volatility3`

### 核心命令

```bash
# 先获取内存镜像（在靶机上）
# Linux: 使用 LiME 或 avml
# Windows: 使用 WinPMEM 或 DumpIt

# Volatility 3 基本命令格式
vol.py -f memory.dmp <plugin>

# 列出运行进程
vol.py -f memory.dmp windows.pslist

# 检测隐藏进程（对比不同方式获取的进程列表）
vol.py -f memory.dmp windows.psscan

# 列出网络连接
vol.py -f memory.dmp windows.netstat

# 提取注册表配置单元
vol.py -f memory.dmp windows.registry.hivelist

# 提取密码哈希（需要 hashdump 插件）
vol.py -f memory.dmp windows.hashdump

# 列出已加载的 DLL
vol.py -f memory.dmp windows.dlllist --pid 1234

# 提取可疑进程的可执行文件
vol.py -f memory.dmp windows.dumpfiles --pid 1234
```

### 核心插件速查

| 插件 | 作用 | 比喻 |
|------|------|------|
| `pslist` | 列进程（按链表） | 看任务管理器 |
| `psscan` | 列进程（扫描内存池） | 翻垃圾找被删除的记录 |
| `pstree` | 进程树 | 看谁是谁的子进程 |
| `netstat` | 网络连接 | 看谁连着谁 |
| `hashdump` | 密码哈希 | 翻保险箱 |
| `hivelist` | 注册表位置 | 找档案柜 |
| `cmdline` | 进程的命令行参数 | 看程序带了什么参数启动 |
| `malfind` | 检测注入代码 | 找藏在别人家里的陌生人 |
| `dumpfiles` | 提取文件 | 把东西搬出来 |

💡 小白提示：`pslist` 和 `psscan` 对比是经典操作——如果某进程在 `psscan` 里有但 `pslist` 里没有，说明它可能在隐藏自己（Rootkit 行为）。

### 进阶技巧

- **分析恶意代码注入**：`malfind` 插件检测哪段内存被注入了可执行代码
- **恢复被删除的文件**：`windows.dumpfiles` 可以从内存中恢复运行过但已删除的文件
- **时间线分析**：`timeliner` 插件按时间排序所有事件，还原攻击时间线

---

## 二、Autopsy —— 数字取证 GUI 工具

### 定位

Autopsy 是 The Sleuth Kit 的图形界面版本，用于磁盘取证分析，能恢复已删除文件、分析文件时间线、搜索关键词等。

### 比喻

> Autopsy 就像一个"硬盘考古工具箱"——把硬盘当成考古现场，翻出被删除的文件、按时间排列事件、搜索藏在角落的证据。

### 安装

- **Kali Linux**：已预装
- **其他**：下载 [sleuthkit.org](https://www.sleuthkit.org/autopsy/)

### 核心功能

| 功能 | 说明 |
|------|------|
| 添加数据源 | 支持磁盘镜像、本地磁盘、逻辑文件 |
| 文件恢复 | 恢复已删除的文件 |
| 关键词搜索 | 在磁盘内容中搜索关键词 |
| 时间线分析 | 按时间排序文件操作事件 |
| 文件类型识别 | 按文件签名识别真实类型（不只看扩展名） |
| 哈希集比对 | 与已知恶意文件哈希库比对 |
| Web 搜索 | 搜索浏览历史、书签等 |

### 基本流程

1. 启动 Autopsy → 新建案件
2. 添加数据源（选择磁盘镜像文件）
3. 配置分析模块（关键词搜索、哈希比对等）
4. 等待分析完成
5. 在左侧面板浏览分析结果

💡 小白提示：Autopsy 最实用的功能是"已删除文件恢复"——在文件列表中标记为红色叉的就是被删除但仍可恢复的文件。

---

## 三、John the Ripper —— 密码破解工具

### 定位

John the Ripper（简称 John）是一款开源密码破解工具，支持数百种哈希格式，通过字典和规则变换进行密码破解。

### 比喻

> John 就像一个"不知疲倦的试钥匙工"——你给它一把锁（密码哈希）和一串钥匙（字典），它一个一个试，还能根据规则自己变出新钥匙。

### 安装

- **Kali Linux**：已预装
- **其他**：`apt install john`

### 核心命令

```bash
# 基础字典破解
john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt

# 自动识别哈希格式
john --wordlist=wordlist.txt hash.txt

# 指定哈希格式
john --format=NT --wordlist=wordlist.txt hash.txt

# 显示已破解的密码
john --show hash.txt

# 恢复中断的破解任务
john --restore

# 只用规则变换（不加载字典）
john --rules hash.txt

# 增量模式（纯暴力，按字符组合穷举）
john --incremental hash.txt
```

### 常见哈希格式

| 格式 | `--format` 参数 | 示例哈希 |
|------|-----------------|---------|
| MD5 | `raw-md5` | `d41d8cd98f00b204e9800998ecf8427e` |
| SHA1 | `raw-sha1` | `da39a3ee5e6b4b0d3255bfef95601890afd80709` |
| NTLM | `NT` | `8846F7EAEE8FB117AD06BDD830B7586C` |
| bcrypt | `bcrypt` | `$2a$05$...` |
| Linux shadow | `sha512crypt` | `$6$...` |

💡 小白提示：
- `rockyou.txt` 是 Kali 自带的最常用密码字典（1400 万条），在 `/usr/share/wordlists/rockyou.txt`（需解压：`gunzip rockyou.txt.gz`）。
- 先用 `--wordlist` 字典模式跑，跑完没出来再用 `--incremental` 暴力模式。暴力模式非常慢。
- `john --show` 查看已破解结果，别跑完了忘记看。

### 提取哈希的方法

```bash
# Linux /etc/shadow 哈希
unshadow /etc/passwd /etc/shadow > hash.txt
john --wordlist=wordlist.txt hash.txt

# Windows NTLM 哈希（需要先获取）
# 方法1：Mimikatz hashdump
# 方法2：Volatility windows.hashdump
# 方法3：impacket-secretsdump
```

---

## 四、Hashcat —— GPU 加速密码破解工具

### 定位

Hashcat 是号称"世界最快的密码破解工具"，利用 GPU 加速，速度比 John 快几个数量级。支持字典、规则、掩码（暴力）等多种攻击模式。

### 比喻

> John 是"一个人慢慢试钥匙"，Hashcat 是"开了一千条流水线同时试"——它用显卡的并行计算能力，同时测试上万个密码。

### 安装

- **Kali Linux**：已预装
- **其他**：`apt install hashcat`

### 核心命令

```bash
# 字典攻击
hashcat -m 0 -a 0 hash.txt wordlist.txt
# -m 0 = MD5, -a 0 = 字典模式

# 字典 + 规则
hashcat -m 0 -a 0 hash.txt wordlist.txt -r best64.rule

# 掩码暴力破解（8位数字）
hashcat -m 0 -a 3 hash.txt ?d?d?d?d?d?d?d?d

# 组合攻击（两个字典拼接）
hashcat -m 0 -a 1 hash.txt dict1.txt dict2.txt

# 查看破解进度
hashcat -m 0 hash.txt --show

# 基准测试（测你的显卡跑多快）
hashcat -b -m 0
```

### 攻击模式

| 模式 `-a` | 名称 | 说明 |
|-----------|------|------|
| 0 | Straight（字典） | 直接用字典里的词 |
| 1 | Combination（组合） | 两个字典的词拼接 |
| 3 | Brute-force（掩码） | 按掩码穷举（如 `?d?d?d?d` = 4位数字） |
| 6 | Hybrid Word+Mask | 字典词 + 掩码后缀 |
| 7 | Hybrid Mask+Word | 掩码前缀 + 字典词 |

### 哈希类型 `-m` 常见值

| `-m` 值 | 类型 |
|---------|------|
| 0 | MD5 |
| 100 | SHA1 |
| 1400 | SHA256 |
| 1000 | NTLM |
| 1800 | sha512crypt (Linux shadow) |
| 3200 | bcrypt |
| 13100 | Kerberoasting (Kerberos TGS) |

💡 小白提示：
- Hashcat 需要 GPU 才能发挥威力。没有独立显卡时用 `--force` 强制 CPU 模式，但速度很慢。
- 掩码字符：`?d`=数字、`?l`=小写字母、`?u`=大写字母、`?s`=特殊字符、`?a`=所有。
- Hashcat 破解结果存在 `.hashcat` 文件中，用 `--show` 查看。

### John vs Hashcat

| | John | Hashcat |
|---|------|---------|
| 计算 | CPU | GPU（也支持 CPU） |
| 速度 | 慢 | 非常快（有 GPU 时） |
| 哈希格式 | 自动识别 | 需要手动指定 `-m` |
| 适合 | 快速试字典、服务器环境 | 大规模密码破解 |

---

## 五、Ghidra —— 开源逆向工程工具

### 定位

Ghidra 是美国 NSA 开源的逆向工程工具（2019 年发布），提供反汇编、反编译、脚本扩展等功能，是 IDA Pro 的免费替代品。

### 比喻

> Ghidra 就像一个"翻译显微镜"——把编译好的二进制程序（机器码）翻译回接近 C 语言的伪代码，让你能看懂程序内部逻辑。

### 安装

- **Kali Linux**：`apt install ghidra`
- **其他**：下载 [ghidra-sre.org](https://ghidra-sre.org/)（需要 JDK 11+）

### 核心功能

| 功能 | 说明 |
|------|------|
| 反汇编 | 把二进制转为汇编代码 |
| 反编译 | 把汇编转为 C 伪代码 |
| 函数图谱 | 可视化函数调用关系 |
| 数据类型恢复 | 识别结构体、数组等数据类型 |
| 脚本扩展 | 支持 Java/Python 脚本 |

### 基本流程

1. 启动 Ghidra → 新建项目
2. 导入二进制文件（File → Import File）
3. 双击文件打开 CodeBrowser
4. 自动分析（Auto Analysis → 等待完成）
5. 在左侧 Symbol Tree 浏览函数
6. 双击函数 → 右侧看反编译的 C 伪代码

💡 小白提示：Ghidra 第一次打开会很慢（自动分析过程），耐心等。反编译的伪代码不是 100% 准确，需要结合汇编理解。

### 进阶技巧

- **搜索字符串**：Search → For Strings，找程序中的字符串常量（如 "password"、"flag"）
- **重命名变量**：双击反编译中的变量名重命名，让代码更可读
- **交叉引用**：右键变量/函数 → References → Find references，看哪里调用了它
- **Ghidra 脚本**：File → Configure → Script Manager，运行分析脚本

---

## 六、IDA Pro / IDA Free —— 逆向工程行业标准

### 定位

IDA Pro 是逆向工程的行业标准（商业软件），IDA Free 是免费版。功能类似 Ghidra，但插件生态更成熟。

### 比喻

> IDA 就像 Ghidra 的"付费豪华版"——功能更全、插件更多、反编译更准（Hex-Rays 反编译器），但收费很贵。

### IDA Free vs Ghidra

| | IDA Free | Ghidra |
|---|----------|--------|
| 价格 | 免费 | 免费（开源） |
| 反编译 | 需要付费插件 | 内置 |
| 插件生态 | 丰富（但很多收费） | 在增长 |
| 学习资料 | 非常多 | 在增长 |
| 适合 | 有经验后升级 | 入门首选 |

💡 小白提示：零基础学逆向，建议从 Ghidra 开始——免费、开源、有反编译功能。等熟练了再考虑 IDA。

---

## 七、foremost / binwalk —— 文件提取工具

### foremost

**定位：** 从数据流中提取文件（文件雕刻）。基于文件头/尾特征识别并提取嵌入文件。

**比喻：** foremost 就像一个"废纸堆里翻照片的人"——给它一堆二进制数据，它能把里面的图片、文档、压缩包翻出来。

```bash
# 从磁盘镜像提取文件
foremost -i image.dd -o output/

# 指定文件类型
foremost -t jpg,png,pdf -i image.dd -o output/

# 从 pcap 提取
foremost -i capture.pcap -o output/
```

### binwalk

**定位：** 分析固件和二进制文件中的嵌入文件和代码。常用于固件逆向。

**比喻：** binwalk 就像一个"快递 X 光机"——扫描一个文件，告诉你里面藏了什么（固件、压缩包、文件系统）。

```bash
# 分析文件中嵌入的内容
binwalk firmware.bin

# 提取嵌入文件
binwalk -e firmware.bin

# 递归提取
binwalk -eM firmware.bin
```

💡 小白提示：CTF Misc 题中，"一个文件里藏了另一个文件"是常见套路。先 `binwalk` 扫一遍看有没有嵌入文件，有的话 `-e` 提取出来。

---

## 工具组合拳：取证分析工具链

```
1. Autopsy 分析磁盘镜像 → 恢复已删除文件、时间线分析
2. Volatility 分析内存镜像 → 提取进程、网络连接、密码哈希
3. John/Hashcat 破解密码 → 从哈希还原明文密码
4. foremost/binwalk 提取嵌入文件 → 从镜像中翻出隐藏文件
5. Ghidra 逆向恶意样本 → 分析恶意程序的行为逻辑
```
