# 安全工具学习方法论

> 本文件不是讲某个具体工具，而是讲"怎么学工具"——学习路线、组合拳设计、工具选型决策、常用操作 checklist。
> 适合不知道从哪开始学、工具太多学不过来、学完就忘的用户。

---

## 一、工具学习路线图

### 核心理念

> **不要试图学会所有工具。** 安全工具几百个，但常用的核心工具不超过 20 个。先精通核心工具，再按需扩展。

### 三阶段学习路线

```
阶段一：三大主力（入门必学）
├── Nmap        → 网络扫描（看清目标）
├── Burp Suite  → Web 抓包（分析请求）
└── sqlmap      → SQL 注入（自动化利用）

阶段二：方向扩展（选方向学）
├── Web 方向    → Nikto + Gobuster + DirBuster
├── 网络方向    → Wireshark + Masscan + tcpdump
├── 利用方向    → Metasploit + Mimikatz + BloodHound
├── 取证方向    → Volatility + Autopsy + foremost/binwalk
├── 密码方向    → John the Ripper + Hashcat
└── 逆向方向    → Ghidra + IDA Free

阶段三：组合与自动化（进阶）
├── 工具组合拳  → 多工具串联使用
├── 脚本自动化  → Python 调用工具 API
└── 工具开发    → 自己写 Burp 插件 / Nmap 脚本
```

### 学每个工具的标准五步法

```
1. 它是干嘛的？→ 用一句话说清工具定位 + 一个生活比喻
2. 怎么装？→ 从下载到验证安装成功
3. 核心功能怎么用？→ 跑通一个最简单的例子
4. 常用参数/操作有哪些？→ 记住 5-10 个最常用的
5. 进阶技巧 → 学会 2-3 个高级用法
```

💡 小白提示：学工具最大的误区是"看文档背参数"。正确方法是"边用边学"——先跑通一个最简单的例子，有了成就感再深入。

---

## 二、工具选型决策树

当用户问"该用什么工具"时，按以下决策树引导：

```
你的目标是什么？
│
├── 扫描目标开了什么端口/服务？
│   ├── 少量目标，要精确 → Nmap
│   └── 大范围，要快速 → Masscan（先扫）→ Nmap（精扫）
│
├── 分析 Web 应用？
│   ├── 抓包改包 → Burp Suite（首选）/ OWASP ZAP（免费平替）
│   ├── 自动找 SQL 注入 → sqlmap
│   ├── 扫 Web 服务器漏洞 → Nikto
│   └── 找隐藏目录 → Gobuster / Feroxbuster
│
├── 利用漏洞打进目标？
│   ├── 有已知漏洞（如永恒之蓝）→ Metasploit
│   ├── 需要隐蔽红队行动 → Cobalt Strike / Havoc / Sliver
│   └── Windows 内网渗透 → MSF + Mimikatz + BloodHound
│
├── 分析网络流量？
│   ├── 有图形界面 → Wireshark
│   └── 服务器命令行 → tcpdump（抓包）→ Wireshark（分析）
│
├── 破解密码？
│   ├── 有 GPU → Hashcat（快）
│   └── 只有 CPU → John the Ripper
│
├── 数字取证？
│   ├── 分析磁盘镜像 → Autopsy
│   ├── 分析内存镜像 → Volatility
│   └── 提取隐藏文件 → foremost / binwalk
│
├── 逆向二进制程序？
│   ├── 入门/免费 → Ghidra
│   └── 进阶/付费 → IDA Pro
│
└── 评估无线网络？
    └── Aircrack-ng 套件（需要监听模式网卡）
```

---

## 三、工具组合拳设计

### 组合拳设计原则

> 单个工具是"一个人在战斗"，组合拳是"团队作战"。设计组合拳的核心逻辑是：**上一个工具的输出 = 下一个工具的输入。**

### 经典组合拳

#### 组合拳 1：Web 渗透标准流程

```
Nmap（扫端口）
  → 输出：80 端口开放
    ↓
Nikto（Web 体检）
  → 输出：发现过时软件、危险配置
    ↓
Gobuster（扫目录）
  → 输出：发现 /admin、/login.php
    ↓
Burp Suite（抓包分析）
  → 输出：发现 login.php 的参数 id 可疑
    ↓
sqlmap（自动注入）
  → 输出：确认 SQL 注入，拿到数据库数据
```

#### 组合拳 2：内网渗透流程

```
Nmap（扫内网）
  → 输出：发现 192.168.1.10 开 445 端口
    ↓
Metasploit（利用 SMB 漏洞）
  → 输出：获得 Meterpreter session
    ↓
Mimikatz（抓内存密码）
  → 输出：获得域用户凭据
    ↓
BloodHound（分析攻击路径）
  → 输出：找到到域管的最短路径
    ↓
横向移动（用凭据登录其他机器）
  → 输出：获得域管权限
```

#### 组合拳 3：应急响应取证流程

```
Volatility（分析内存镜像）
  → 输出：发现可疑进程 PID 1234
    ↓
Autopsy（分析磁盘镜像）
  → 输出：发现恶意程序文件
    ↓
Ghidra（逆向恶意程序）
  → 输出：理解恶意程序行为（C2 地址、加密方式）
    ↓
Wireshark（分析网络流量）
  → 输出：确认与 C2 的通信记录
    ↓
编写检测规则（IOC 提取）
  → 输出：用于全网排查
```

#### 组合拳 4：CTF Misc 常用流程

```
binwalk（扫描嵌入文件）
  → 输出：发现隐藏的 ZIP
    ↓
foremost（提取文件）
  → 输出：得到 ZIP 文件
    ↓
John/Hashcat（破解 ZIP 密码）
  → 输出：解压得到 flag 文件
    ↓
strings/exiftool（检查文件内容）
  → 输出：发现隐藏的 flag
```

---

## 四、常用操作 Checklist

### Nmap 扫描 Checklist

```
□ 确认目标在授权范围内
□ 确定扫描范围（单 IP / 网段）
□ 选择扫描类型：
  □ -sn（只发现主机）
  □ -sV（服务版本）
  □ -O（操作系统）
  □ -A（综合）
□ 确定端口范围：
  □ -F（快速，常见 100 端口）
  □ -p-（全端口）
  □ -p 80,443,8080（指定端口）
□ 设置速度：-T4（推荐）
□ 保存结果：-oN result.txt
□ 执行扫描
□ 分析结果：open 端口 = 可攻击面
```

### Burp Suite 抓包 Checklist

```
□ 确认在靶场/授权环境操作
□ 启动 Burp Suite
□ 确认 Proxy 监听 127.0.0.1:8080
□ 配置浏览器代理
□ 安装 Burp CA 证书（访问 http://burp）
□ 开启 Intercept（Proxy → Intercept is on）
□ 浏览器访问目标
□ 请求被 Burp 拦截
□ 检查请求内容（参数、Cookie、Header）
□ 右键 → Send to Repeater
□ 在 Repeater 中修改请求 → Send → 分析响应
```

### sqlmap 注入 Checklist

```
□ 确认在靶场/授权环境操作
□ 确认目标 URL 有参数（如 ?id=1）
□ 如果需要登录态，用 Burp 抓 Cookie
□ 基础检测：sqlmap -u "URL" --cookie="xxx" --batch
□ 判断是否注入成功
□ 如果成功：
  □ --dbs（看有哪些数据库）
  □ --current-db（看当前数据库）
  □ -D dbname --tables（看表）
  □ -D dbname -T tablename --columns（看列）
  □ -D dbname -T tablename -C col1,col2 --dump（导数据）
□ 如果失败：
  □ --level=5（提高检测级别）
  □ --risk=3（提高风险级别）
  □ --tamper="space2comment"（尝试绕过 WAF）
```

### MSF 利用 Checklist

```
□ 确认在靶场/授权环境操作
□ 确定目标漏洞（如 MS17-010 永恒之蓝）
□ msfconsole 启动
□ search 搜索对应模块
□ use 选择模块
□ show options 查看需配置参数
□ set RHOSTS 目标IP
□ set LHOST 本机IP
□ set PAYLOAD（如需要）
□ check（如果模块支持，检测目标是否 vulnerable）
□ exploit / run
□ 成功 → 进入 Meterpreter / Shell
□ 失败 → 检查目标是否真有漏洞、防火墙是否挡了
```

---

## 五、工具学习常见误区

### 误区 1：试图学会所有工具

> **问题：** Kali 里几百个工具，看哪个都想学，结果哪个都没学会。
> **正确做法：** 精通 3 个核心工具（Nmap + Burp + sqlmap），然后按方向扩展。其他工具用到时再学。

### 误区 2：只看文档不实操

> **问题：** 看 Nmap 参数文档看了半天，实际没敲过一条命令。
> **正确做法：** 每学一个参数就敲一遍。搭个靶场，对着真实输出学。

### 误区 3：背参数不学原理

> **问题：** 记住了 `nmap -sV` 但不知道 -sV 是什么意思。
> **正确做法：** -sV = service version。为什么要探测版本？因为漏洞跟版本绑定。理解了"为什么"才记得住。

### 误区 4：工具用完了不留记录

> **问题：** 做完实验不知道记什么，下次又要从头来。
> **正确做法：** 记录"工具 + 命令 + 输出 + 分析"。形成了自己的工具速查手册。

### 误区 5：只学攻击工具不学防御工具

> **问题：** 只学 Nmap、MSF、Burp，不学 Wireshark、Volatility。
> **正确做法：** 攻防一体。扫描工具也是防御者用来发现资产的工具，取证工具是防御者的核心武器。

---

## 六、Kali Linux 工具生态速览

Kali Linux 预装了 600+ 安全工具，按类别整理常用工具：

| 类别 | 常用工具 |
|------|---------|
| 信息收集 | Nmap, Masscan, Recon-ng, theHarvester, Shodan |
| 漏洞分析 | Nikto, Nuclei, OpenVAS, Legion |
| Web 应用 | Burp Suite, ZAP, sqlmap, WPScan, Commix |
| 密码攻击 | John, Hashcat, Hydra, Medusa, Crunch |
| 无线攻击 | Aircrack-ng, Reaver, Wifite, Kismet |
| 漏洞利用 | Metasploit, SearchSploit, ExploitDB |
| 嗅探欺骗 | Wireshark, tcpdump, Responder, Ettercap |
| 后渗透 | Mimikatz, Empire, BloodHound, CrackMapExec |
| 取证 | Volatility, Autopsy, foremost, binwalk, ExifTool |
| 逆向 | Ghidra, IDA Free, Radare2, GDB, objdump |
| 报告 | CherryTree, Dradis, Faraday |

💡 小白提示：Kali 菜单按类别分组，不知道某类有什么工具时去菜单里翻。`apt search keyword` 也能搜相关工具。
